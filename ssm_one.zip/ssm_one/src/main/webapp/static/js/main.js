
require.config({
    baseUrl: '/static/js',
    paths: {
        css:'css.min',
        jquery: 'tools/jquery.min',
        underscore:'tools/underscore',
        bootstrap:'tools/bootstrap.min',
        html5shiv:'tools/html5shiv',
        respond:'tools/respond.min',
        page:'page/page'
    },
    shim: {
        underscore: {
            exports: '_'
        },
        bootstrap:{
            deps:["jquery",'css!../css/bootstrap.min.css']
        },
        page:{
            deps:["bootstrap","css!../css/font.css","css!../css/main.css","css!../css/style.css"]
        }

    }
});


