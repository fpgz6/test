// JavaScript Document

//全局加载事件
$(function () {
	dateTimePicker();
});

/*===============================================*/
/*加事件*/
//var globalEvent = {
 /*日期时间选择器*/
    function dateTimePicker() {
		if($(".dateSet").length>0||$(".timeSet").length>0||$(".YMSet").length>0||$(".dateTimeSet").length>0){
        /*日期*/
        $(".dateSet").dynDateTime();
        /*时间*/
        $(".timeSet").dynDateTime({
            showsTime: true,
            ifFormat: "%H:%M"
        });
        /*年月*/
        $(".YMSet").dynDateTime({
            ifFormat: "%Y-%m"
        });
        /*日期+时间*/
        $(".dateTimeSet").dynDateTime({
            showsTime: true,
            ifFormat: "%Y-%m-%d %H:%M:00",
            onOpen: function(s) {
                var dom = $(".calendar")[0];
                var top = parseInt(dom.style.top, 10);
                dom.style.top = (top+document.body.scrollTop)+"px";
            }
        });}
    }
//}

//var loadingMask = {
//	//设置屏蔽层
//	setLoading : function(a){
//		this.removeLoading(a);
//		var h = $(a).outerHeight();
//		var w = $(a).outerWidth();
//		var l = $(a).position().left;
//		var t = $(a).position().top;
//		var str = $('<div class="data-loading"><div class="data-loading-mask"></div><div class="data-loading-ico"></div></div>');
//		str.css({
//			'height':h, 
//			'width':w, 
//			'left':l,
//			'top':t
//		});
//		$(a).after(str);
//	},
//	//移除屏蔽层
//	removeLoading : function(a){
//		if($(a).next('.data-loading').length != 0){
//			$(a).next('.data-loading').remove();
//		}
//	},
//	setError : function(a, str){
//		this.removeLoading(a);
//		var h = $(a).outerHeight();
//		var w = $(a).outerWidth();
//		var l = $(a).position().left;
//		var t = $(a).position().top;
//		var str = $('<div class="data-loading"><div class="data-loading-mask"></div><div class="data-error">'+str+'</div></div>');
//		str.css({
//			'height':h, 
//			'width':w, 
//			'left':l,
//			'top':t
//		});
//		$(a).after(str);
//	}
//}