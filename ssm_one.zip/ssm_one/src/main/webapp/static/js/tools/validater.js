var validater = {
	isMobile : function(mobile) {
		return (/^(?:1[34587]\d)-?\d{5}(\d{3}|\*{3})$/.test($.trim(mobile)));
	},
	isIDCardNo:function(id){
		return idCardValidate(id);
	},
	isBankCardNo:function(bankno){
//		var regex = /^\d{16,19}$|^\d{6}[- ]\d{10,13}$|^\d{4}[- ]\d{4}[- ]\d{4}[- ]\d{4,7}$/;
//		if(regex.test(bankno)&&bankCardValidate(bankno))
//			return true;
//		else
//			return false;
		var regex = /^[0-9]\d{9,49}$/;
		if(regex.test(bankno))
			return true;
		else
			return false;
		
	},
	isEmail:function(email){
		var regex =/^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
		if(regex.test(email))
			return true;
		else
			return false;
	},
    isTaxNumber:function(taxNumber){
        return taxNumberValidate(taxNumber);
    },
    isBankNumber:function(bankNumber){
        return bankNumberValidate(bankNumber);
    }

};
/**
 * 身份证15位编码规则：dddddd yymmdd xx p dddddd：地区码 yymmdd: 出生年月日 xx: 顺序类编码，无法确定 p:
 * 性别，奇数为男，偶数为女
 * <p />
 * 身份证18位编码规则：dddddd yyyymmdd xxx y dddddd：地区码 yyyymmdd: 出生年月日
 * xxx:顺序类编码，无法确定，奇数为男，偶数为女 y: 校验码，该位数值可通过前17位计算获得
 * <p />
 * 
 */

var provinceAndCities={11:"北京",12:"天津",13:"河北",14:"山西",15:"内蒙古",21:"辽宁",22:"吉林",23:"黑龙江",
    31:"上海",32:"江苏",33:"浙江",34:"安徽",35:"福建",36:"江西",37:"山东",41:"河南",42:"湖北",43:"湖南",44:"广东",
    45:"广西",46:"海南",50:"重庆",51:"四川",52:"贵州",53:"云南",54:"西藏",61:"陕西",62:"甘肃",63:"青海",64:"宁夏",
    65:"新疆",71:"台湾",81:"香港",82:"澳门",91:"国外"};


var powers=["7","9","10","5","8","4","2","1","6","3","7","9","10","5","8","4","2"];// 加权因子


var  parityBit= ["1","0","X","9","8","7","6","5","4","3","2"];// 身份证验证位值

function idCardValidate(idCard) {
	if (idCard.length == 15) {
		return check15IdCardNo(idCard);
	} else if (idCard.length == 18) {
		return check18IdCardNo(idCard);
	} else {
		return false;
	}
}


//校验15位的身份证号码
function check15IdCardNo(idCardNo){
    //15位身份证号码的基本校验
    var check = /^[1-9]\d{7}((0[1-9])|(1[0-2]))((0[1-9])|([1-2][0-9])|(3[0-1]))\d{3}$/.test(idCardNo);
    if(!check) return false;
    //校验地址码
    var addressCode = idCardNo.substring(0,6);
    check = checkAddressCode(addressCode);
    if(!check) return false;
    var birthDayCode = '19' + idCardNo.substring(6,12);
    //校验日期码
    return checkBirthDayCode(birthDayCode);
}
//校验18位的身份证号码
function check18IdCardNo(idCardNo){
    //18位身份证号码的基本格式校验
    var check = /^[1-9]\d{5}[1-9]\d{3}((0[1-9])|(1[0-2]))((0[1-9])|([1-2][0-9])|(3[0-1]))\d{3}(\d|x|X)$/.test(idCardNo);
    if(!check) return false;
    //校验地址码
    var addressCode = idCardNo.substring(0,6);
    check = checkAddressCode(addressCode);
    if(!check) return false;
    //校验日期码
    var birthDayCode = idCardNo.substring(6,14);
    check = checkBirthDayCode(birthDayCode);
    if(!check) return false;
    //验证校检码
    return checkParityBit(idCardNo);
}

//判断身份证号码为18位时最后的验证位是否正确
function checkParityBit(idCardNo){
    var parityBit = idCardNo.charAt(17).toUpperCase();
    if(getParityBit(idCardNo) == parityBit){
        return true;
    }else{
        return false;
    }
}

function getParityBit(idCardNo){
    var id17 = idCardNo.substring(0,17);

    var power = 0;
    for(var i=0;i<17;i++){
        power += parseInt(id17.charAt(i),10) * parseInt(powers[i]);
    }

    var mod = power % 11;
    return parityBit[mod];
}
//校验地区码
function checkAddressCode(addressCode){
    var check = /^[1-9]\d{5}$/.test(addressCode);
    if(!check) return false;
    if(provinceAndCities[parseInt(addressCode.substring(0,2))]){
        return true;
    }else{
        return false;
    }
}
//校验日期码
function checkBirthDayCode(birthDayCode){
    var check = /^[1-9]\d{3}((0[1-9])|(1[0-2]))((0[1-9])|([1-2][0-9])|(3[0-1]))$/.test(birthDayCode);
    if(!check) return false;
    var yyyy = parseInt(birthDayCode.substring(0,4),10);
    var mm = parseInt(birthDayCode.substring(4,6),10);
    var dd = parseInt(birthDayCode.substring(6),10);
    var xDate = new Date(yyyy,mm-1,dd);
    if(xDate > new Date()){
        return false;//生日不能大于当前日期
    }else if ( ( xDate.getFullYear() == yyyy ) && ( xDate.getMonth () == mm - 1 ) && ( xDate.getDate() == dd ) ){
        return true;
    }else{
        return false;
    }
}



/**
 * 
 *Description:  银行卡号Luhm校验 此验证规则只适用于2000年的国标
 *Luhm校验规则：16位银行卡号（19位通用）:
 *1.将未带校验位的 15（或18）位卡号从右依次编号 1 到 15（18），位于奇数位号上的数字乘以 2。
 *2.将奇位乘积的个十位全部相加，再加上所有偶数位上的数字。
 *3.将加法和加上校验位能被 10 整除。
 */


//bankno为银行卡号
function bankCardValidate(bankno){
	bankno = bankno.replace(/[- ]+/g, "");    // 去除空白和横杠
	var lastNum=bankno.substr(bankno.length-1,1);//取出最后一位（与luhm进行比较）
	  
	var first15Num=bankno.substr(0,bankno.length-1);//前15或18位
	var newArr=new Array();
	for(var i=first15Num.length-1;i>-1;i--){    //前15或18位倒序存进数组
		newArr.push(first15Num.substr(i,1));
	}
	var arrJiShu=new Array();  //奇数位*2的积 <9
	var arrJiShu2=new Array(); //奇数位*2的积 >9
	     
	var arrOuShu=new Array();  //偶数位数组
	for(var j=0;j<newArr.length;j++){
		if((j+1)%2==1){//奇数位
	        if(parseInt(newArr[j])*2<9)
	        	arrJiShu.push(parseInt(newArr[j])*2);
	        else
	        	arrJiShu2.push(parseInt(newArr[j])*2);
	    }
	    else //偶数位
	    	arrOuShu.push(newArr[j]);
	} 
		
	var jishu_child1=new Array();//奇数位*2 >9 的分割之后的数组个位数
	var jishu_child2=new Array();//奇数位*2 >9 的分割之后的数组十位数
	for(var h=0;h<arrJiShu2.length;h++){
		jishu_child1.push(parseInt(arrJiShu2[h])%10);
	    jishu_child2.push(parseInt(arrJiShu2[h])/10);
	}        
	var sumJiShu=0; //奇数位*2 < 9 的数组之和
	var sumOuShu=0; //偶数位数组之和
	var sumJiShuChild1=0; //奇数位*2 >9 的分割之后的数组个位数之和
	var sumJiShuChild2=0; //奇数位*2 >9 的分割之后的数组十位数之和
	var sumTotal=0;
	for(var m=0;m<arrJiShu.length;m++){
	    sumJiShu=sumJiShu+parseInt(arrJiShu[m]);
	}
	    
	for(var n=0;n<arrOuShu.length;n++){
		sumOuShu=sumOuShu+parseInt(arrOuShu[n]);
	}
	     
	for(var p=0;p<jishu_child1.length;p++){
		sumJiShuChild1=sumJiShuChild1+parseInt(jishu_child1[p]);
		sumJiShuChild2=sumJiShuChild2+parseInt(jishu_child2[p]);
	}     
	//计算总和
	sumTotal=parseInt(sumJiShu)+parseInt(sumOuShu)+parseInt(sumJiShuChild1)+parseInt(sumJiShuChild2);
	     
	//计算Luhm值
	var k= parseInt(sumTotal)%10==0?10:parseInt(sumTotal)%10;       
	var luhm= 10-k;
	     
	if(lastNum == luhm)
		return true;
	else
	    return false;
	         
}

/**
 * 校验税号
 * @param taxNumber
 */
function taxNumberValidate(taxNumber){

    var check = /^(((\d|[a-zA-Z]){14})(\d|x|X))|(\d{17})|(\d{17}(\d|x|X))|(\d{17}(\d|x|X)\d{2})$/.test(taxNumber);
    if(!check) return false;

    if(taxNumber.length == 15){
        return checkTaxNumber(taxNumber);
    }else if(taxNumber.length == 17){
        var first15 = taxNumber.substr(0, 15);
        return idCardValidate(first15);
    }else if(taxNumber.length == 18){
        return idCardValidate(taxNumber);
    }else if(taxNumber.length == 20){
        var first18 = taxNumber.substr(0, 18);
        return idCardValidate(first18);
    }else{
        return false;
    }

}

function checkTaxNumber(taxNumber){
    //截取后9位
    var last9 = taxNumber.substr(taxNumber.length-9, taxNumber.length);
    var lastF8 = new Array();
    for(var i=0; i<8; i++) {
        lastF8[i] = convertCharacterToNumber(last9.charAt(i));
    }
    var w = new Array(3, 7, 9, 10, 5, 8, 4 ,2);
    var temp = 0;
    for(var i=0; i<8; i++) {
        temp += lastF8[i] * w[i];
    }
    temp = 11 - temp % 11;
    if(temp == 10){
        return (last9.charAt(8)=='X' || last9.charAt(8)=='x');
    }else if(temp == 11){
        return last9.charAt(8)=='0';
    }else{
        return last9.charAt(8) == temp;
    }
}
function convertCharacterToNumber(character) {
    if(!isNaN(character)){
        return character;
    }
    switch(character) {
        case 'A':
        case 'a':return 10;
        case 'B':
        case 'b':return 11;
        case 'C':
        case 'c':return 12;
        case 'D':
        case 'd':return 13;
        case 'E':
        case 'e':return 14;
        case 'F':
        case 'f':return 15;
        case 'G':
        case 'g':return 16;
        case 'H':
        case 'h':return 17;
        case 'I':
        case 'i':return 18;
        case 'J':
        case 'j':return 19;
        case 'K':
        case 'k':return 20;
        case 'L':
        case 'l':return 21;
        case 'M':
        case 'm':return 22;
        case 'N':
        case 'n':return 23;
        case 'O':
        case 'o':return 24;
        case 'P':
        case 'p':return 25;
        case 'Q':
        case 'q':return 26;
        case 'R':
        case 'r':return 27;
        case 'S':
        case 's':return 28;
        case 'T':
        case 't':return 29;
        case 'U':
        case 'u':return 30;
        case 'V':
        case 'v':return 31;
        case 'W':
        case 'w':return 32;
        case 'X':
        case 'x':return 33;
        case 'Y':
        case 'y':return 34;
        case 'Z':
        case 'z':return 35;
        default:alert("税号中有非法字符");
    }
}


/**
 * 联行号校验：使用模10、11双模校验算法（GB/T 17710）。
 *校验公式：

 * (...((...(((M+an)//M*2)/(M+1)+an-1)//(M*2)/(M+1)+...+a1)//M*2)/(M+1)+...+a1)//M=1

 *    式中：n-----包括校验字符在内的代码字符的总个数;

 *         an-----为代码左端第1位数字;

 *         M 与M+1------两个模数，M=10;

 *         //M------式中前面的结果除以M后的整余数，若除尽无余数用M代替；

 *         /(M+1)-------式中前面的结果除以(M+1)后的整余数

 *   注：字符处理顺序从左至右。校验字符放在代码字符串的最右端。
 *检验算法：
 *  本情况下，n=12,将12位联行号从左到右逐个用a12,a11,a10...a1,对应为banknumber[0]......bankNumber[11];
 *  采取递归算法，i=0,1,2,...11;当i =0时定义P[i] = 10;
 *  递归：
 *      S[i]=P[i]|11+bankNumber[i];
 *      P[i+1] = (S[i]||10) *2
 *  最终判断
 *      S[11]|10=1;
 * @param bankNumber
 */
function bankNumberValidate(bankNumber){
    var regex = /^[0-9]\d{11}$/;
    if(regex.test(bankNumber) == false)
        return false;
    return mod10AndMod11(bankNumber);
}

/**
 * 模10，11双模校验
 * @param number
 * @returns {boolean}
 */
function mod10AndMod11(number){
    var P = 10;//初始化P=10
    var S;
    for(var i= 0; i < number.length-1; i++){//j:0....length-2
        P=P%11;
        S = P + parseInt(number[i]);//S[i]
        S=S%10;
        if(S == 0)
            S = 10;
        P = S*2;//P[i+1]
        //        if(j=number.length-2){
//            if((P+number[number.length-1])%10 != 1)
//                return false;
//        }
    }
    S = P%11+parseInt(number[number.length-1]);//S[length-1]
    if(S%10 != 1){
        return false;
    }
    return true;
}