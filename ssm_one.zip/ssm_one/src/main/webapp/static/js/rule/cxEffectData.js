define([],function(){
//	查询
	$(".searchData").bind("click",function(){
		var form = document.forms['queryForm'];
		var startTime = $("#startTime").val();
		var endTime = $("#endTime").val();
		if(startTime==""||endTime==""){
			alert("日期不能为空");
			return false;
		}
		$("#pageIndex").val('0');
		form.submit();
	});
	$(".exportData").bind("click",function(){
		var pin = $("#pin").val();
		var startTime = $("#startTime").val();
		var endTime = $("#endTime").val();
		var source = $("#source").val();
		var firstId = $("#firstId").val();
		var secondId = $("#secondId").val();
		var thirdId = $("#thirdId").val();
		if(startTime==""||endTime==""){
			alert("日期不能为空");
			return false;
		}
		$.ajax({
			url : "/mng/cx/categoryEffect/getCount",
			data : {
				'pin' : pin,
				'startTime' : startTime,
				'endTime' : endTime,
				'source' : source,
				'firstId' : firstId,
				'secondId' : secondId,
				'thirdId' : thirdId
			},
			type : "post",
			cache: false,
			dataType : 'json',
			error : function() {
				alert("代码出错，请稍后再试！");
			},
			success : function(data) {
				if(data.success==1){
					var form = document.forms['queryForm'];
					$("#pageIndex").val('0');
					form.action = '/mng/cx/categoryEffect/exportCategoryEffect';
					form.submit();
					form.action = '/mng/cx/categoryEffect/dataList';
				}else{
					alert(data.msg);
				}
			},
		});
	});
});