function checkInput(str) {  
	var patrn=/[`~!@#$%^&*_+<>?\/:"{}'[\]]/im;  
    if(patrn.test(str)){  
        return false;     
    }     
    return true;  
} 
/**
* 校验小数合法,整数,一位二位小数

function IsDecimals(dec_data){
	
	var decReg=/^[0-9]+(.[0-9]{1})?$/;
	var re=new RegExp(decReg);
	if (re.test(dec_data)){
		return true;
	}else{
		return false;
	}
}*/
function IsDecimals(dec_data){
	var intReg = new RegExp(/^[0-9]+$/);
	var decReg = new RegExp(/^[0-9]+[.]{1}[0-9]{1,2}$/);
	if (intReg.test(dec_data)) {
		return true;
	} else if (decReg.test(dec_data)) {
		return true;
	} else {
		return false;
	}
}
var formId="queryForm";

function newSetting(){
	var channel=$("#channel").val();
	$.ajax({
		url : "/mng/commRange/isCreate",
		type : 'post',
		data : {'channel' : channel
		},
		dataType : 'json',
		error : function() {
			alert("代码出错，请稍后再试！");
		},
		success : function(data) {
			if(data.isCreate == "false"){
				alert('不能新建佣金分成范围设置');
			}else{
				window.location.href='/mng/commRange/newCommRange/' + channel;
			}
		}
	});
}

function saveComm(){
	$('#aa').html('');
	var h = '<span><a class="btn btnM" onclick="saveComm();"> <span><em>提交</em></span> </a></span>';
	var startDate=$("#startDate").val();
	if(startDate==''){
		alert('请输入起始日期');
		$('#aa').html(h);
		return false;
	}
	var endDate=$("#endDate").val();
	if(endDate==''){
		alert('请输入结束日期');
		$('#aa').html(h);
		return false;
	}
	var startArr = startDate.split("-");
	var endArr = endDate.split("-");
	var d1 = new Date(startArr[0],3 + parseInt(startArr[1],10) - 1,startArr[2]);
	var d2 = new Date(endArr[0],parseInt(endArr[1],10) - 1,parseInt(endArr[2],10) + 1);
	if(d1 > d2){
		alert('结束日期不能小于起始日期,并且跨度不能小于3个月!');
		$('#aa').html(h);
		return false;
	}
	var ids = $('#ids').val();
	var idsArr = ids.split(",");
	for ( var i = 0; i < idsArr.length; i++) {
		var sPrice = $('#startPrice_'+idsArr[i]).val();
		var ePrice = $('#endPrice_'+idsArr[i]).val();
		var sPricePop = $('#startPricePop_'+idsArr[i]).val();
		var ePricePop = $('#endPricePop_'+idsArr[i]).val();
		if(sPrice == '' || ePrice == ''){
			alert('请输入自营范围');
			$('#aa').html(h);
			return false;
		}
		if(checkInput(sPrice)==false || IsDecimals(sPrice)==false){
			alert('请正确输入自营范围');
			$('#aa').html(h);
			return false;
		}
		if(checkInput(ePrice)==false || IsDecimals(ePrice)==false){
			alert('请正确输入自营范围');
			$('#aa').html(h);
			return false;
		}
		if(Number(sPrice) >= Number(ePrice)){
			alert('自营范围最大值应大于最小值');
			$('#aa').html(h);
			return false;
		}
		if(sPricePop == '' || ePricePop == ''){
			alert('请输入POP范围');
			$('#aa').html(h);
			return false;
		}
		if(checkInput(sPricePop)==false || IsDecimals(sPricePop)==false){
			alert('请正确输入POP范围');
			$('#aa').html(h);
			return false;
		}
		if(checkInput(ePricePop)==false || IsDecimals(ePricePop)==false){
			alert('请正确输入POP范围');
			$('#aa').html(h);
			return false;
		}
		if(Number(sPricePop) >= Number(ePricePop)){
			alert('POP范围最大值应大于最小值');
			$('#aa').html(h);
			return false;
		}
	}
	var form = document.forms['queryForm'];
	form.submit();
}

function modifyComm(pk,sPrice,ePrice,sPricePop,ePricePop) {
	var html = "";
	html += "<input id='startPrice_"+pk+"' name='startPrice_"+pk+"' type='text' class='textField4 mr5' value='"+sPrice+"'/>%";
	html += " — ";
	html += "<input id='endPrice_"+pk+"' name='endPrice_"+pk+"' type='text' class='textField4 mr5' value='"+ePrice+"'/>%";
	$('#txtPrice_'+pk).html(html);
	var pophtml = "";
	pophtml += "<input id='startPricePop_"+pk+"' name='startPricePop_"+pk+"' type='text' class='textField4 mr5' value='"+sPricePop+"'/>%";
	pophtml += " — ";
	pophtml += "<input id='endPricePop_"+pk+"' name='endPricePop_"+pk+"' type='text' class='textField4 mr5' value='"+ePricePop+"'/>%";
	$('#txtPricePop_'+pk).html(pophtml);
	$('#btnModify_'+pk).html("<a href='javascript:void(0)' onclick='updateComm("+pk+");'>保存</a>");
}
function updateComm(pk) {
	var priceStart = $('#startPrice_'+pk).val();
	var priceEnd = $('#endPrice_'+pk).val();
	var priceStartPop = $('#startPricePop_'+pk).val();
	var priceEndPop = $('#endPricePop_'+pk).val();
	if(priceStart == '' || priceEnd == ''){
		alert('请输入自营范围');
		return false;
	}
	if(checkInput(priceStart)==false || IsDecimals(priceStart)==false){
		alert('请正确输入自营范围');
		return false;
	}
	if(checkInput(priceEnd)==false || IsDecimals(priceEnd)==false){
		alert('请正确输入自营范围');
		return false;
	}
	if(Number(priceStart) >= Number(priceEnd)){
		alert('自营范围最大值应大于最小值');
		return false;
	}
	if(priceStartPop == '' || priceEndPop == ''){
		alert('请输入POP范围');
		return false;
	}
	if(checkInput(priceStartPop)==false || IsDecimals(priceStartPop)==false){
		alert('请正确输入POP范围');
		return false;
	}
	if(checkInput(priceEndPop)==false || IsDecimals(priceEndPop)==false){
		alert('请正确输入POP范围');
		return false;
	}
	if(Number(priceStartPop) >= Number(priceEndPop)){
		alert('POP范围最大值应大于最小值');
		return false;
	}
	var settingId = $('#settingId').val();
	$.ajax({
		url : "/mng/commRange/updateCommRangeCategory",
		type : 'post',
		data : {
			'id' : pk,
			'rangeId' : settingId,
			'priceStart' : priceStart,
			'priceEnd' : priceEnd,
			'priceStartPop' : priceStartPop,
			'priceEndPop' : priceEndPop
		},
		dataType : 'json',
		error : function() {
			alert("代码出错，请稍后再试！");
		},
		success : function(data) {
			$('#txtPrice_'+pk).html(priceStart+" % — "+priceEnd+" %");
			$('#txtPricePop_'+pk).html(priceStartPop+" % — "+priceEndPop+" %");
			$('#btnModify_'+pk).html("<a href='javascript:void(0)' onclick='modifyComm("+pk+","+priceStart+","+priceEnd+","+priceStartPop+","+priceEndPop+");'>修改</a>");
			alert(data.msg);
		}
	});

}
function addComm(categoryId,categoryName,flag) {
	$('#btnModify_c_'+categoryId).html('');
	var h = '<a href="javascript:void(0)" onclick="addComm("'+categoryId+'","'+categoryName+'","'+flag+'");">保存</a>';
	var priceStart = $('#startPrice_'+categoryId).val();
	var priceEnd = $('#endPrice_'+categoryId).val();
	var priceStartPop = $('#startPricePop_'+categoryId).val();
	var priceEndPop = $('#endPricePop_'+categoryId).val();
	if(priceStart == '' || priceEnd == ''){
		alert('请输入自营范围');
		$('#btnModify_c_'+categoryId).html(h);
		return false;
	}
	if(checkInput(priceStart)==false || IsDecimals(priceStart)==false){
		alert('请正确输入自营范围');
		$('#btnModify_c_'+categoryId).html(h);
		return false;
	}
	if(checkInput(priceEnd)==false || IsDecimals(priceEnd)==false){
		alert('请正确输入自营范围');
		$('#btnModify_c_'+categoryId).html(h);
		return false;
	}
	if(Number(priceStart) >= Number(priceEnd)){
		alert('自营范围最大值应大于最小值');
		$('#btnModify_c_'+categoryId).html(h);
		return false;
	}
	if(priceStartPop == '' || priceEndPop == ''){
		alert('请输入POP范围');
		$('#btnModify_c_'+categoryId).html(h);
		return false;
	}
	if(checkInput(priceStartPop)==false || IsDecimals(priceStartPop)==false){
		alert('请正确输入POP范围');
		return false;
	}
	if(checkInput(priceEndPop)==false || IsDecimals(priceEndPop)==false){
		alert('请正确输入POP范围');
		$('#btnModify_c_'+categoryId).html(h);
		return false;
	}
	if(Number(priceStartPop) >= Number(priceEndPop)){
		alert('POP范围最大值应大于最小值');
		$('#btnModify_c_'+categoryId).html(h);
		return false;
	}
	var settingId = $('#settingId').val();
	$.ajax({
		url : "/mng/commRange/addCommRangeCategory",
		type : 'post',
		data : {
			'categoryId' : categoryId,
			'categoryName' : categoryName,
			'rangeId' : settingId,
			'priceStart' : priceStart,
			'priceEnd' : priceEnd,
			'priceStartPop' : priceStartPop,
			'priceEndPop' : priceEndPop
		},
		dataType : 'json',
		error : function() {
			alert("代码出错，请稍后再试！");
		},
		success : function(data) {
			$('#txtPrice_c_'+categoryId).attr('id','txtPrice_'+data.id);
			$('#txtPricePop_c_'+categoryId).attr('id','txtPricePop_'+data.id);
			$('#btnModify_c_'+categoryId).attr('id','btnModify_'+data.id);
			$('#txtPrice_'+data.id).html(priceStart+" % — "+priceEnd+" %");
			$('#txtPricePop_'+data.id).html(priceStartPop+" % — "+priceEndPop+" %");
			if(flag=='1')
				$('#btnModify_'+data.id).html("<a href='javascript:void(0)' onclick='modifyComm("+data.id+","+priceStart+","+priceEnd+","+priceStartPop+","+priceEndPop+");'>修改</a>");
			else
				$('#btnModify_'+data.id).html("--");
			alert(data.msg);
		}
	});
	
}
function saveDate() {
	var startDate=$("#startDate").val();
	if(startDate==''){
		alert('请输入起始日期');
		return false;
	}
	var endDate=$("#endDate").val();
	if(endDate==''){
		alert('请输入结束日期');
		return false;
	}
	var startArr = startDate.split("-");
	var endArr = endDate.split("-");
	var d1 = new Date(startArr[0],3 + parseInt(startArr[1],10) - 1,startArr[2]);
	var d2 = new Date(endArr[0],parseInt(endArr[1],10) - 1,parseInt(endArr[2],10) + 1);
	if(d1 > d2){
		alert('结束日期不能小于起始日期,并且跨度不能小于3个月!');
		return false;
	}
	var settingId = $('#settingId').val();
	$.ajax({
		url : "/mng/commRange/updateCommRange",
		type : 'post',
		data : {
			'id' : settingId,
			'startDate' : startDate,
			'endDate' : endDate
		},
		dataType : 'json',
		error : function() {
			alert("代码出错，请稍后再试！");
		},
		success : function(data) {
			$('#lblEndDate').html(data.endDate);
			$('#lblEndDate1').html("");
			alert(data.msg);
		}
	});
	
}
function showCommission(id,flag) {
	var channel=$("#channel").val();
	window.location.href='/mng/commRange/showDetail/'+id+'/'+flag+'/'+channel;
}
function rangeList() {
	var channel=$("#channel").val();
	window.location.href='/mng/commRange/list/'+channel;
}

