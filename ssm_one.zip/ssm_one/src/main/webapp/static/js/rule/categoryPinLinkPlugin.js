/**
 * 类目三级联动插件+pin
 * @author: zhaopeng
 * @date: 2016-06-12
 */
$(function() {
    var CategoryPinLink = function(dom, settings) {
        this.dom = dom;
        this.settings = {
            pin:null,//采销pin
            firstId: null,//一级类目
            secondId: null,//二级类目
            thirdId: null,//三级类目
            pinValue:null,
            firstSearchValue: null,//一级类目的查询条件
            secondSearchValue: null,//二级类目的查询条件
            thirdSearchValue: null//三级类目的查询条件
        };
        this.pinDom = null;
        this.firstCategoryDom = null;
        this.secondCategoryDom = null;
        this.thirdCategoryDom = null;
        $.extend(this.settings, settings);
    };

    CategoryPinLink.prototype = {
        constructor: CategoryPinLink,
        init: function() {
            var that = this;
            this._validateAndSet();
            this.firstCategoryDom.attr("disabled", true);
            this.secondCategoryDom.attr("disabled", true);
            this.thirdCategoryDom.attr("disabled", true);
            //处理采销pin
            this._dealPin();
            //处理一级类目
            this._dealFirstCategory();
            //处理二级类目
            this._dealSecondCategory();

        },
        _dealPin: function() {
            var that = this;
            this._getPins(function(data) {
                $.each(data, function(index, d) {
                    var option = "<option value='"+d+"'>"+d+"</option>";
                    that.dom.append(option);
                });
                that.dom.append("<option value='all'>未绑定</option>");
                //处理查询条件回写
                if(that.settings.pinValue) {
                    that.dom.val(that.settings.pinValue);
                    that.dom.trigger("change");//手动触发pin的change事件
                }
            });

            this.dom.bind("change", function(e) {
                var pin = $("#pin").val();
                that.firstCategoryDom.empty();
                that.firstCategoryDom.removeAttr("disabled");
                that._getFirstCategoryByPin(pin, function(data) {
                    that.firstCategoryDom.append("<option value=''>全部</option>");
                    $.each(data, function(index, d) {
                        var option = "<option value='"+d.id+"'>"+d.name+"</option>";
                        that.firstCategoryDom.append(option);
                    });
                    //处理查询条件回写
                    if(that.settings.firstSearchValue) {
                        that.firstCategoryDom.val(that.settings.firstSearchValue);
                        that.firstCategoryDom.trigger("change");//手动触发一级类目change事件
                    }
                })
            });
        },
        _dealFirstCategory: function() {
            var that = this;
            this.firstCategoryDom.bind("change", function(e) {
                var fatherId = $("#firstId").val();
                that.secondCategoryDom.empty();
                that.secondCategoryDom.removeAttr("disabled");
                that._getCategoryByFatherId(fatherId, function(data) {
                    that.secondCategoryDom.append("<option value=''>全部</option>");
                    $.each(data, function(index, d) {
                        var option = "<option value='"+d.id+"'>"+d.name+"</option>";
                        that.secondCategoryDom.append(option);
                    });
                    //处理查询条件回写
                    if(that.settings.secondSearchValue) {
                        that.secondCategoryDom.val(that.settings.secondSearchValue);
                        that.secondCategoryDom.trigger("change");//手动触发二级类目change事件
                    }
                })
            });
        },
        _dealSecondCategory: function() {
            var that = this;
            this.secondCategoryDom.bind("change", function(e) {
                var fatherId = $("#secondId").val();;
                that.thirdCategoryDom.empty();
                that.thirdCategoryDom.removeAttr("disabled");
                that._getCategoryByFatherId(fatherId, function(data) {
                    that.thirdCategoryDom.append("<option value=''>全部</option>");
                    $.each(data, function(index, d) {
                        var option = "<option value='"+d.id+"'>"+d.name+"</option>";
                        that.thirdCategoryDom.append(option);
                    });
                    //处理查询条件回写
                    if(that.settings.thirdSearchValue) {
                        that.thirdCategoryDom.val(that.settings.thirdSearchValue);
                    }
                })
            })
        },
        _validateAndSet: function() {
            var _settings = this.settings;
            var pin = _settings.pin;
            var firstId = _settings.firstId;
            var secondId = _settings.secondId;
            var thirdId = _settings.thirdId;
            if(!(pin && firstId && secondId && thirdId)){
                throw Error("settings error:"+JSON.stringify(_settings));
            }
            this.firstCategoryDom = $("#"+firstId);
            this.secondCategoryDom = $("#"+secondId);
            this.thirdCategoryDom = $("#"+thirdId);
        },
        _getPins: function(callback) {
            $.ajax({
                type:"GET",
                url:"/mng/category/query/cx/pin",
                data:{},
                dataType:"json",
                success: function(data) {
                    callback(data)
                },
                error: function(error) {

                }
            })
        },
        _getFirstCategoryByPin: function(pin,callback) {
            if(pin == null || pin == "" || pin == undefined){
                callback([]);
                return;
            }
            $.ajax({
                type:"GET",
                url:"/mng/category/query/first/"+pin,
                data:{},
                dataType:"json",
                success: function(data) {
                    callback(data)
                },
                error: function(error) {

                }
            })
        },
        _getCategoryByFatherId: function(fatherId,callback) {
            if(fatherId == null || fatherId == "" || fatherId == undefined){
                callback([]);
                return;
            }
            $.ajax({
                type:"GET",
                url:"/mng/category/query/"+fatherId,
                data:{},
                dataType:"json",
                success: function(data) {
                    callback(data)
                },
                error: function(error) {

                }
            })
        }
    };

    $.fn.categoryPinLink = function(options) {

        var $this = $(this);
        var pin = $this.attr("id");
        var config = {
            pin: pin
        };
        var settings = $.extend({},config,options);
        var categoryPinLink = new CategoryPinLink($this, settings);
        return categoryPinLink.init();
    }
});

