define([],function(){

	/**
	 * POP基础类目佣金-新建规则
	 */
	$("#openSave").bind("click",function(){
        validateStatus();
	});

    /**
     * 新建规则验证
     */
    function validateStatus(){
        $.ajax({
            url : "/mng/comm/rule/validateRule",
            data : {
                'ruleType' : 3,
                'source' : $("#source").val()
            },
            type : "post",
            cache: false,
            dataType : 'json',
            error : function() {
                alert("代码出错，请稍后再试！");
            },
            success : function(data) {
                if(data.content.status==2){
                    alert("已经创建【未开始】规则， 请不要重复创建！");
                }else if(data.content.status==1){
                    var newStartTime = nextDay(data.content.endTime).format("yyyy-MM-dd");
                    $('#startTime').val(newStartTime);
                    $("#newRule").click();
                }else{
                    $('#startTime').val(nextDay().format("yyyy-MM-dd"));
                    $("#newRule").click();
                }
            }
        });

    };
//    function validateStatus(){
//        var flag = false;
//        $('tbody').children('tr').each(function(){
//            if($(this).attr('data-status') == 1) {
//                var newStartTiime = nextDay($(this).attr('data-endtime')).format("yyyy-MM-dd")
//                $('#startTime').val(newStartTiime);
//            }
//            if($(this).attr('data-status') == 2) {
//                flag = true;
//            }
//        })
//        return flag;
//    }
	
	/**
	 * 删除
	 */
	$(".del").bind("click",function(){
		var e = $(this);
		var delUrl = '/mng/comm/rule/del/usual/';
		if(window.confirm('确认删除设置吗?')){
			$.ajax({
		    	url : delUrl + $(e).parents('tr').attr("data-id"),
			    success : function(data) {
			    	_successFun(data);
			    	if(data.code == 1) 
			    	    $(e).parents('tr').remove();
			    },
		        error   : _errorFun
		    })
		}else{
			return false;
		};

	});
	
	/**
	 * 修改比例
	 */
	$(".update").bind("click",function(){
		var type = $(this).data("type");
		var url = $(this).data("url");
		$.ajax({
			url : url,
			cache: false,
			error : function() {
				alert("代码出错，请稍后再试！");
			},
			success : function(data) {
				$('#ruleId').val(data.content.id);
				$('#cusRatio').val(data.content.customRatio);
				$('#lblDate').html(data.content.startTime + " 至 " + data.content.endTime);
				if(type == 2)
					$('#lblName').html(data.content.name);
			}
		});
	});

    /**
     * pop基础类目佣金新建规则-保存
     */
    $("#save").bind("click",function(){
        if(validateRule()) {
            $('#ruleForm').submit();
        }
    });

    /**
     * pop基础类目佣金新建规则-保存验证
     */
    function validateRule() {
        if($('#name').size() > 0 && !hasText($('#name').val())) {
            alert("请填写规则名称!");
            return;
        }
        var customRatio = $('#customRatio').val();
        if($('#customRatio').size() > 0 && !hasText(customRatio)) {
            alert("请填写佣金比例!");
            return;
        }else{
            if(checkInput(customRatio)==false || IsInt(customRatio)==false ||
                customRatio < 0 || customRatio > 100){
                alert('请正确输入佣金比例范围');
                return false;
            }
        }
        var startTime = $('#startTime').val();
        var endTime = $('#endTime').val();
        return dateCompare(startTime, endTime);
    }

    /**
     * pop基础类目佣金-列表修改佣金比例-保存
     */
    $("#updateRatio").bind("click",function(){
        var type = $(this).data("updatetype");
        var channel = $('#source').val();
        var customRatio = $('#cusRatio').val();
        if($('#cusRatio').size() > 0 && !hasText(customRatio)) {
            alert("请填写佣金比例!");
            return;
        }else{
            if(checkInput(customRatio)==false || IsInt(customRatio)==false ||
                customRatio < 0 || customRatio > 100){
                alert('请正确输入佣金比例范围');
                return false;
            }
        }
        var ruleId = $('#ruleId').val();
        $.ajax({
            url : "/mng/comm/rule/update/usual",
            type : 'post',
            cache: false,
            data : {
                'ruleId' : ruleId,
                'cusRatio' : customRatio
            },
            dataType : 'json',
            error : function() {
                alert("代码出错，请稍后再试！");
            },
            success : function(data) {
                _successFun(data);
                if(type == 1)
                    window.location.href = "/mng/comm/rule/usual/" + channel;
                if(type == 2)
                    window.location.href = "/mng/comm/rule/directed/" + channel;
                if(type == 3)
                    window.location.href = "/mng/comm/rule/bonus/" + channel;
            }
        });
    });
	
	//新建复制规则
	$(".copyNew").bind("click",function(){
		var ruleId = $(this).data("ruleid");
		var customRatio = $(this).data("rto");
		validStatus(ruleId, customRatio);
	});

    /**
     * 新建复制规则验证
     */
	function validStatus(ruleId, customRatio){
        $.ajax({
            url : "/mng/comm/rule/validateRule",
            data : {
                'ruleType' : 3,
                'source' : $("#source").val()
            },
            type : "post",
            cache: false,
            dataType : 'json',
            error : function() {
                alert("代码出错，请稍后再试！");
            },
            success : function(data) {
                if(data.content.status==2){
                    alert("已经创建【未开始】规则， 请不要重复创建！");
                }else if(data.content.status==1){
                    var newStartTime = nextDay(data.content.endTime).format("yyyy-MM-dd");
                    $('#sTime').val(newStartTime);
                    $('#cRatio').val(parseInt(customRatio));
                    $('#rId').val(ruleId);
                    $("#copyNewRule").click();
                }else{
                    $('#sTime').val(nextDay().format("yyyy-MM-dd"));
                    $('#cRatio').val(parseInt(customRatio));
                    $('#rId').val(ruleId);
                    $("#copyNewRule").click();
                }
            }
        });

    };
    var checkSubmitFlg = false; 
	//新建复制规则保存
	$("#saveCopy").unbind("click").bind("click",function(){
		if(validateCopyRule()) {
			if (!checkSubmitFlg) {          
				checkSubmitFlg = true;              
				$('#copyUsualForm').submit();
			}else{          
				alert("不能重复提交");          
				return false;         
			} 
		}
	});
	function validateCopyRule() {
		if($('#rName').size() > 0 && !hasText($('#rName').val())) {
			alert("请填写规则名称!");
			return false;
		}
		var customRatio = $('#cRatio').val();
		if($('#cRatio').size() > 0 && !hasText(customRatio)) {
			alert("请填写佣金比例!");
			return false;
		}else{
			if(checkInput(customRatio)==false || IsInt(customRatio)==false ||
					customRatio < 0 || customRatio > 100){
				alert('请正确输入佣金比例范围');
				return false;
			}
		}
		var startTime = $('#sTime').val();
		var endTime = $('#eTime').val();
		return dateCompare(startTime, endTime);
	};
});