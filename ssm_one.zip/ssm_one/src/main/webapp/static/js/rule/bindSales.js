define([],function(){
//	查询
	$(".searchBindSales").bind("click",function(){
		var form = document.forms['queryForm'];
		var inputStr1=$("#pin").val();
		var flag1 = checkInput(inputStr1);
		if (!flag1) {
			$("#pin").val('');
			return false;
		}
		if(flag1){
			$("#pageIndex").val('0');
			form.submit();
		}
	});
	$(".ignoreRemindOp").bind("click",function(){
		var id = $(this).parents('tr').attr("data-thirdid");
		$("#id_3").val(id);
	});
	//忽略提醒
	$(".ignoreRemind").bind("click",function(){
		var thirdId = $("#id_3").val();
		$.ajax({
			url : "/mng/sales/ignoreRemind",
			data : {
				'thirdId' : thirdId
			},
			type : "post",
			cache: false,
			dataType : 'json',
			error : function() {
				alert("代码出错，请稍后再试！");
			},
			success : function(data) {
				_successFun(data);
				if(data.code==1)
				{
					location.reload();
				}	
			},
		});
	});
	$(".showhistoryOp").bind("click",function(){
		var id = $(this).parents('tr').attr("data-thirdid");
		$.ajax({
			url : "/mng/sales/findHistory",
			data : {
				'thirdId' : id
			},
			type : "post",
			cache: false,
			dataType : 'json',
			error : function() {
				alert("代码出错，请稍后再试！");
			},
			success : function(data) {
				var obj = data.historys;
				var result = "<table class='table table-bordered margin-0'>";
				result += "<thead><tr><td>操作</td><td>绑定时间</td><td>绑定京挑客账号</td></tr></thead><tbody>";
				$(obj).each(function(ind){ 
					result += "<tr>"; 
					result += "<td>绑定</td>"; 
					result += "<td>" + obj[ind].beginDate + "</td>"; 
					result += "<td>" + obj[ind].pin + "</td>"; 
					result += "</tr>"; 
				}); 
				result += "</tbody></table>"; 
				$('.history').html(result);
			},
		});
	});
	$(".exportBindSales").bind("click",function(){
		var form = document.forms['queryForm'];
		var inputStr1=$("#pin").val();
		var flag1 = checkInput(inputStr1);
		if (!flag1) {
			$("#pin").val('');
			return false;
		}
		if(flag1){
			$("#pageIndex").val('0');
			form.action = '/mng/sales/export';
			form.submit();
			form.action = '/mng/sales/bindList';
		}
	});
});