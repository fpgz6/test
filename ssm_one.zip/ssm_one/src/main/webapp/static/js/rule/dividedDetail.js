function checkInput(str) {  
	var patrn=/[`~!@#$%^&*_+<>?\/:"{}'[\]]/im;  
    if(patrn.test(str)){  
        return false;     
    }     
    return true;  
} 
/**
* 校验小数合法,整数,一位二位小数

function IsDecimals(dec_data){
	
	var decReg=/^[0-9]+(.[0-9]{1})?$/;
	var re=new RegExp(decReg);
	if (re.test(dec_data)){
		return true;
	}else{
		return false;
	}
}*/
function IsDecimals(dec_data){
	var intReg = new RegExp(/^[0-9]+$/);
	var decReg = new RegExp(/^[0-9]+[.]{1}[0-9]{1,2}$/);
	if (intReg.test(dec_data)) {
		return true;
	} else if (decReg.test(dec_data)) {
		return true;
	} else {
		return false;
	}
}
var formId="queryForm";

function payTypeChange(element) {
    var theValue = $(element).val();
    $(element).parent().find("input[name='unit']").val("");
    if (theValue == "1") {
        $(element).parent().find("span").text('元');
    }
    else if (theValue == "2") {
        $(element).parent().find("span").text('%');
    }
}

function addDivided() {
	var rows = $("#rows").val();
	var rowcount = 1;
	if (rows != "") {
		if (rows.indexOf(",") == -1) {
			rowcount = rowcount + 1;
		} else {
			var arr = rows.split(",");
//			alert(arr.length);
//			alert(arr[arr.length - 1].value);
			rowcount = parseInt(arr[arr.length - 2]) + 1;
		}
	}
	var resultHtml = "";
	resultHtml += "<tr id='add_"+rowcount+"'>";
	resultHtml += "<td><input type=\"text\" id=\"add_start_" + rowcount + "\" name=\"add_start_" + rowcount + "\" class=\"textField18 mr5\" value=\"0\"/>元 - ";
	resultHtml += "<input type=\"text\" id=\"add_end_" + rowcount + "\" name=\"add_end_" + rowcount + "\" class=\"textField18 mr5\"/>元</td>";
	resultHtml += "<td><select name=\"add_type_" + rowcount + "\" id=\"add_type_" + rowcount + "\" class=\"select18\" onchange=\"payTypeChange(this);\">";
	resultHtml += "<option value=\"2\">百分比</option>";
	resultHtml += "<option value=\"1\">定额</option>";
	resultHtml += "</select> <input type=\"text\" id=\"add_price_" + rowcount + "\" name=\"add_price_" + rowcount + "\" class=\"textField18 mr5\"><span id=\"unit\">%</span></td>";
	resultHtml += "<td><a href=\"javascript:delTr(" + rowcount + ");\" class='text-info'>删除</a></td>";
	resultHtml += "</tr>";
	$("table").append(resultHtml);
	rows += rowcount + ",";
	$("#rows").val(rows);
//	alert($("#rows").val());
}

function delTr(rowcount) {
	$("#add_"+rowcount).remove();
	var rows = $("#rows").val();
//	alert(rows);
	if (rows != "") {
		if (rows.indexOf(",") == -1) {
			if(rows == rowcount){
				$("#rows").val("");
				return false;
			}
		} else {
			var arr = rows.split(",");
			for (var i = 0; i < arr.length; i++) {
                if (arr[i] == rowcount){
                	arr.splice(i, 1);
                }
            }
			$("#rows").val(arr.join(","));
		}
	}
}

function delDivided(id) {
	var delIds = $("#delIds").val();
	delIds += id + ",";
	$("#delIds").val(delIds);
	$("#mod_"+id).remove();
}

function saveDivided(e) {
//	$('#aa').attr('disabled', true);
	$('#aa').html('');
	var h = '<span><a class="btn btnM" onclick="saveDivided(this);"> <span><em>提交</em></span> </a></span>';
	var nosearch = $("#nosearch").val();
	var delIds = $("#delIds").val();
	var rows = $("#rows").val();
	if (nosearch == "false") {
		var id = "";
		$("input[name='settingId']").each(function(i){
			id += $(this).val() + ",";
			$("#modIds").val(id);
		});
		
	}
	var modIds = $("#modIds").val();
	if(modIds == '' && rows == ''){
		alert('至少需要设置一种梯度规则');
		$('#aa').html(h);
		return ;
	}
	if (modIds != '') {
		var modIdsArr = modIds.split(",");
		for ( var i = 0; i < modIdsArr.length - 1; i++) {
			var sPrice = $('#mod_start_'+modIdsArr[i]).val();
			var ePrice = $('#mod_end_'+modIdsArr[i]).val();
			var price = $('#mod_price_'+modIdsArr[i]).val();
			if(sPrice == ''){
				alert('请输入金额起始梯度');
				$('#aa').html(h);
				return ;
			}else{
				if(checkInput(sPrice)==false || IsDecimals(sPrice)==false){
					alert('请正确输入金额起始梯度');
					$('#aa').html(h);
					return ;
				}
			}
			if((ePrice == '' && i < modIdsArr.length - 2) || (ePrice == '' && i < modIdsArr.length - 1 && rows != '')){
				alert('请输入金额结束梯度');
				$('#aa').html(h);
				return ;
			}else{
				if (ePrice != '') {
					if(checkInput(ePrice)==false || IsDecimals(ePrice)==false){
						alert('请正确输入金额结束梯度');
						$('#aa').html(h);
						return ;
					}
					if(Number(sPrice) >= Number(ePrice)){
						alert('金额结束梯度应大于金额起始梯度');
						$('#aa').html(h);
						return ;
					}
				}
			}
			if (i > 0) {
				var preStartPrice = $('#mod_start_'+modIdsArr[i-1]).val();
				var preEndPrice = $('#mod_end_'+modIdsArr[i-1]).val();
				if(Number(sPrice) >= Number(preStartPrice) && Number(sPrice) < Number(preEndPrice)){
					alert('已经设置该金额梯度，请重新设置');
					$('#aa').html(h);
					return ;
				}
			}
			if(price == ''){
				alert('请输入奖励额度');
				$('#aa').html(h);
				return ;
			}
			if(checkInput(price)==false || IsDecimals(price)==false){
				alert('请正确输入奖励额度');
				$('#aa').html(h);
				return ;
			}
		}
	}
	if (rows != '') {
		var idsArr = rows.split(",");
		for ( var i = 0; i < idsArr.length - 1; i++) {
			var sPrice = $('#add_start_'+idsArr[i]).val();
			var ePrice = $('#add_end_'+idsArr[i]).val();
			var price = $('#add_price_'+idsArr[i]).val();
			if(sPrice == ''){
				alert('请输入金额起始梯度');
				$('#aa').html(h);
				return ;
			}else{
				if(checkInput(sPrice)==false || IsDecimals(sPrice)==false){
					alert('请正确输入金额起始梯度');
					$('#aa').html(h);
					return ;
				}
			}
			if(ePrice == '' && i < idsArr.length - 2){
				alert('请输入金额结束梯度');
				$('#aa').html(h);
				return ;
			}else{
				if (ePrice != '') {
					if(checkInput(ePrice)==false || IsDecimals(ePrice)==false){
						alert('请正确输入金额结束梯度');
						$('#aa').html(h);
						return ;
					}
					if(Number(sPrice) >= Number(ePrice)){
						alert('金额结束梯度应大于金额起始梯度');
						$('#aa').html(h);
						return ;
					}
				}
			}
			if (i > 0) {
				var preStartPrice = $('#add_start_'+idsArr[i-1]).val();
				var preEndPrice = $('#add_end_'+idsArr[i-1]).val();
				if(Number(sPrice) >= Number(preStartPrice) && Number(sPrice) < Number(preEndPrice)){
					alert('已经设置该金额梯度，请重新设置');
					$('#aa').html(h);
					return ;
				}
			}
			if (modIds != '') {
				var modIdsArr = modIds.split(",");
				for ( var j = 0; j < modIdsArr.length - 1; j++) {
					var preStartPrice = $('#mod_start_'+modIdsArr[j]).val();
					var preEndPrice = $('#mod_end_'+modIdsArr[j]).val();
					if(Number(sPrice) >= Number(preStartPrice) && Number(sPrice) < Number(preEndPrice)){
						alert('已经设置该金额梯度，请重新设置');
						$('#aa').html(h);
						return ;
					}
				}
			}
			if(price == ''){
				alert('请输入奖励额度');
				$('#aa').html(h);
				return ;
			}
			if(checkInput(price)==false || IsDecimals(price)==false){
				alert('请正确输入奖励额度');
				$('#aa').html(h);
				return ;
			}
		}
	}

	var form = document.forms['queryForm'];
	form.action = "/mng/dividedDetail/submitDivided";
	form.submit();
}

