/**
 * 类目三级联动插件
 * @author: wangsiyuan
 * @date: 2016-02-03
 */
$(function() {
    var CatogeryLink = function(dom, settings) {
        this.dom = dom;
        this.settings = {
            firstId: null,//一级类目
            secondId: null,//二级类目
            thirdId: null,//三级类目
            firstSearchValue: null,//一级类目的查询条件
            secondSearchValue: null,//二级类目的查询条件
            thirdSearchValue: null//三级类目的查询条件
        };
        this.secondCategoryDom = null;
        this.thirdCategoryDom = null;
        $.extend(this.settings, settings);
    };

    CatogeryLink.prototype = {
        constructor: CatogeryLink,
        init: function() {
            var that = this;
            this._validateAndSet();
            this.secondCategoryDom.attr("disabled", true);
            this.thirdCategoryDom.attr("disabled", true);
            //处理一级类目
            this._dealFirstCategory();
            //处理二级类目
            this._dealSecondCategory();

        },
        _dealFirstCategory: function() {
            var that = this;
            this._getFirstCatogery(function(data) {
                that.dom.append("<option value=''>全部</option>");
                $.each(data, function(index, d) {
                    var option = "<option value='"+d.id+"'>"+d.name+"</option>";
                    that.dom.append(option);
                });
                //处理查询条件回写
                if(that.settings.firstSearchValue) {
                    that.dom.val(that.settings.firstSearchValue);
                    that.dom.trigger("change");//手动触发一级类目change事件
                }
            });

            this.dom.bind("change", function(e) {
                var fatherId = $(this).val();
                that.secondCategoryDom.empty();
                that.secondCategoryDom.removeAttr("disabled");
                //console.log("fatherId:"+fatherId);
                that._getCatogeryByFatherId(fatherId, function(data) {
                    that.secondCategoryDom.append("<option value=''>全部</option>");
                    $.each(data, function(index, d) {
                        var option = "<option value='"+d.id+"'>"+d.name+"</option>";
                        that.secondCategoryDom.append(option);
                    });
                    //处理查询条件回写
                    if(that.settings.secondSearchValue) {
                        that.secondCategoryDom.val(that.settings.secondSearchValue);
                        that.secondCategoryDom.trigger("change");//手动触发二级类目change事件
                    }
                })
            });

        },
        _dealSecondCategory: function() {
            var that = this;
            this.secondCategoryDom.bind("change", function(e) {
                var fatherId = $(this).val();
                that.thirdCategoryDom.empty();
                that.thirdCategoryDom.removeAttr("disabled");
                that._getCatogeryByFatherId(fatherId, function(data) {
                    that.thirdCategoryDom.append("<option value=''>全部</option>");
                    $.each(data, function(index, d) {
                        var option = "<option value='"+d.id+"'>"+d.name+"</option>";
                        that.thirdCategoryDom.append(option);
                    });
                    //处理查询条件回写
                    if(that.settings.thirdSearchValue) {
                        that.thirdCategoryDom.val(that.settings.thirdSearchValue);
                    }
                })
            })
        },
        _validateAndSet: function() {
            var _settings = this.settings;
            var firstId = _settings.firstId;
            var secondId = _settings.secondId;
            var thirdId = _settings.thirdId;
            if(!(firstId && secondId && thirdId)){
                throw Error("settings error:"+JSON.stringify(_settings));
            }
            this.secondCategoryDom = $("#"+secondId);
            this.thirdCategoryDom = $("#"+thirdId);
            if(this.secondCategoryDom[0] && this.thirdCategoryDom[0]) {

            } else {
                throw Error("dom not exist.");
            }
        },
        _getFirstCatogery: function(callback) {
            $.ajax({
                type:"GET",
                url:"/mng/category/query/first",
                data:{},
                dataType:"json",
                success: function(data) {
                    callback(data)
                },
                error: function(error) {

                }
            })
        },
        _getCatogeryByFatherId: function(fatherId,callback) {
            if(fatherId == null || fatherId == "" || fatherId == undefined){
                callback([]);
                return;
            }
            $.ajax({
                type:"GET",
                url:"/mng/category/query/"+fatherId,
                data:{},
                dataType:"json",
                success: function(data) {
                    callback(data)
                },
                error: function(error) {

                }
            })
        }
    };

    $.fn.catogeryLink = function(options) {

        var $this = $(this);
        var firstId = $this.attr("id");
        var config = {
            firstId: firstId
        };
        var settings = $.extend({},config,options);
        var catogeryLink = new CatogeryLink($this, settings);
        return catogeryLink.init();
    }
});

