var formId = 'queryForm';
var saveHtml = '<a class="btn-primary btn" onclick="saveDivided()" href="#">提交</a>';
var updateHtml = '<a onclick="updDivided()" class="btn-primary btn" href="#">更新</a>';
var deletedDetails = [];

$(function(){
	
	
    basicTemplete = $('tr[name=basicTemplete]');
    

	//--
    //修改时，下个梯度的起始值则可以修改
    $('input[name=priceEnd]').blur(function(){
    	var nextTr = $(this).parents('tr').next();
    	if(nextTr.size() == 1) {
    		nextTr.find('input[name=priceStart]').attr('readonly', false).focus();
    	}
    })
    
    //默认最后一个梯度才可以删除
    $('input[name=priceEnd]').each(function() {
        if(!hasText($(this).val())) {
        	$(this).parents('tr').find('span[name=del]').show();
        }
    })
    
    $('select[name=type]').change(function() {
    	if($(this).val() == 1){
            $(this).parent('span').next().find("input[type=text]").next().text('元');
    	}
    	else {
            $(this).parent('span').next().find("input[type=text]").next().text('%');
    	}
    })
	
	//--

    specificTemplete = $('div[name=specificTemplete]');
    
    $('select[name=specificType]').change(function() {
    	var td = $(this).parent();
    	if($(this).val() == 1){
    		td.next().show();
    		td.next().next().hide();
    	}
    	else {
    		td.next().hide();
    		td.next().next().show();
    	}
    })
    
    loadSpecificSelect();
});

function loadSpecificSelect() {
    $('div[name=specific]').each(function() {
    	$(this).find('td[name=order]').each(function(){
    		var orderTd = $(this);
    		var orderTypeId = orderTd.attr('data-ordertypeid');
    		if(hasText(orderTypeId)) {
    			orderTd.prev().hide();
    			orderTd.show();
    			orderTd.children('select').val(orderTypeId);
    		}
    	});
    })
};

/**
 * 规则设置提交
 */
function saveDivided(){
	//防止重复提交(禁用按钮方式有问题)
	var ruleDivideds = getRuleDivideds();
	if(ruleDivideds) {
        $('#saveSpan').html(null);
		//submit
		$.ajax({
			url         : '/mng/comm/rule/savedivided',
			type        : 'post',
		    contentType : 'application/json;charset=UTF-8',
			data        : jsonToString(ruleDivideds),
	    	success     : function(data) {
	    		$('#updateSpan').html(updateHtml);
//	    		_successFun(data);
	    		if(data.code == 1) {
//	    			location.reload();
                    window.location.href=$("#returnUrl").val();
	    		}
	    	},
	    	error       : function() {
    			$('#saveSpan').html(saveHtml);
	    		_errorFun
	    	}
		})
	}
	else {
		$('#saveSpan').html(saveHtml);
	}
};

/**
 * 规则更新
 */
function updDivided(){
	//防止重复提交(禁用按钮方式有问题)
	$('#updateSpan').html(null);
	var ruleDivideds = getRuleDivideds();
	if(ruleDivideds) {
		//submit
		$.ajax({
			url         : '/mng/comm/rule/upddivided',
			type        : 'post',
			contentType : 'application/json;charset=UTF-8',
			data        : jsonToString(ruleDivideds),
	    	success     : function(data) {
	    		$('#updateSpan').html('<a id="updDivided" class="btn-primary btn" href="#">更新</a>');
//	    		_successFun(data);
	    		if(data.code == 1) {
//	    			location.reload();
                    window.location.href=$("#returnUrl").val();
	    		}
	    	},
	    	error       : function() {
	    		$('#updateSpan').html(updateHtml);
	    		_errorFun
	    	}
		})
	}
	else {
		$('#updateSpan').html(updateHtml);
	}
};

function getRuleDivideds() {
	var ruleDivideds = [];
	//basic
	var basicDivided = _getBasicDivided();
	if(basicDivided == null) {
		return null;
	}
	ruleDivideds.push(basicDivided);
	
	//deleted
	var deletedDivided = _getDeletedDividedDetails();
	if(deletedDivided.dividedDetailList.length > 0)
		ruleDivideds.push(deletedDivided);
	
	//specific
	if($('div[name=specific]').size() == 0) {
		return ruleDivideds;
	}
	var specificDivieds = _getSpecificDivideds();
	if(specificDivieds == null) {
		return null;
	}
	for(var i=0;i<specificDivieds.length;i++) {
		ruleDivideds.push(specificDivieds[i]);
	}
	return ruleDivideds;
};

/**
 * <p>
 * 获取规则梯度对象
 * @returns 返回多个divided对象，这些divided为特殊梯度设置
 */
function _getSpecificDivideds() {
	var specificDivideds = [];
	var specifics = $('div[name=specific]');
	var flag = true;
	//保存目录ID值，以便校验目录是否重复
	var cates = [];
	specifics.each(function(){
		var specificList = [];
		var tbody = $(this).find('tbody[name=specific]');
		tbody.children('tr').each(function() {
			var id = $(this).attr('data-id');
			var specific = {
				id         : hasText(id) ? id : null,
				channel    : $('#channel').val(),
				priceStart : $(this).find('input[name=priceStart]').val(),
				priceEnd   : $(this).find('input[name=priceEnd]').val(),
				type       : $(this).find('select[name=type]').val(),
				price      : $(this).find('input[name=price]').val(),
				ruleType   : $('#ruleType').val()
			}
			specificList.push(specific);
		})
		//校验梯度详情
		if(!validateDividedDetails(specificList)) {
			flag = false;
			return;
		}
		//校验目录或者订单类型是否选择
		var typeId = $(this).find('select[name=specificType]').val();
		var cateIdSecond = -1;
		var orderTypeId = -1;
		if(typeId == 1) {
			cateIdSecond = $(this).find('select[name=cateIdSecond]').val();
			cateIdThird = $(this).find('select[name=cateIdThird]').val();
			if(cateIdSecond < 0) {
				alert("请至少选择一个二级目录！")
				flag = false;
				return;
			}
			//校验目录不能重复设置
			var cate = {cateIdSecond : cateIdSecond, cateIdThird : cateIdThird};
			for(var i = 0, len = cates.length; i < len; i++) {
				if(cates[i].cateIdSecond == cateIdSecond && cates[i].cateIdThird == cateIdThird) {
					alert("目录有重复，请重新设置！")
					flag = false;
					return;
				}
			}
			cates.push(cate);
		}
		else {
			orderTypeId = $(this).find('select[name=orderTypeId]').val();
			if(orderTypeId < 0) {
				alert("请选择一个订单类型！");
				flag = false;
				return;
			}
		}

		//组装特殊梯度设置数据
		var cateIdThird = $(this).find('select[name=cateIdThird]').val();
		var id = tbody.attr('data-id');
		var specificDivided = {
			ruleDividedId     : hasText(id) ? id : null,
			ruleId            : $('#ruleId').val(),
			cateIdFirst       : $('#cateId').val(),
//			cateNameFirst     : $('#cateName').val(),
			cateIdSecond      : cateIdSecond == -1 ? null : cateIdSecond,
			cateNameSecond    : cateIdSecond == -1 ? null : $(this).find('select[name=cateIdSecond] :selected').text(),
			cateIdThird       : cateIdThird == -1 ? null : cateIdThird,
			cateNameThird     : cateIdThird == -1 ? null : $(this).find('select[name=cateIdThird] :selected').text(),
			orderTypeId       : orderTypeId == -1 ? null : orderTypeId,
			dividedDetailList : specificList
		}
		specificDivideds.push(specificDivided);
	})
	return flag == true ? specificDivideds : null;
};

/**
 * <p>
 * 获取规则梯度对象
 * @returns 返回一个divided对象，该divided为基础梯度设置
 */
function _getBasicDivided() {
	var details = [];
	var tbody = $('tbody[name=basic]');
	tbody.children('tr').each(function() {
		var id = $(this).attr('data-id');
		var detail = {
	        id         : hasText(id) ? id : null,
	        channel    : $('#channel').val(),
			priceStart : $(this).find('input[name=priceStart]').val(),
			priceEnd   : $(this).find('input[name=priceEnd]').val(),
			type       : $(this).find('select[name=type]').val(),
			price      : $(this).find('input[name=price]').val(),
			ruleType   : $('#ruleType').val()
		}
		details.push(detail);
	})
	
	if(details.length < 1){
		alert('请至少设置一个梯度！');
		return null;
	}
	
	//校验梯度详情
	if(!validateDividedDetails(details)) {
		return null;
	}
	
	var divided = {
			ruleDividedId     : tbody.attr('data-id'),
			ruleId            : $('#ruleId').val(),
			cateIdFirst       : $('#cateId').val(),
			dividedDetailList : details,
			ruleType   		  : $('#ruleType').val()
	}
	return divided;
};

function validateDividedDetails(divideds) {
    var length = divideds.length;
	for(var i=0; i<length; i++) {
		//最后一个梯度单独校验【终结金额必须为空】
		if(i == length -1 && !_validateLastDividedDetail(divideds[i])) 
			return false;
		//校验其余梯度【终结金额必须为空】
		if(i < length -1 && !_validateDividedDetail(divideds[i])) 
			return false;
		//校验当前梯度起始值是否是上一个梯度的结束值
		if(i > 0 && parseFloat(divideds[i].priceStart) != parseFloat(divideds[i-1].priceEnd)) {
			alert("梯度起始值必须等于上一个梯度的结束值！");
			return false;
		}
	}
	return true;
};

function _validateLastDividedDetail(divided) {
	if(!isPositive($.trim(divided.priceStart))) {
		alert("请设置恰当的起始金额！");
		return false;
	}
	if(hasText(divided.priceEnd)) {
		alert('终结金额必须为空！');
		return false;
	}
	if(!isPositive(divided.price) || divided.price < 0) {
		alert("请设置恰当的分成比列和额度！");
		return false;
	}
	return true;
};

function _validateDividedDetail(divided) {
	if(!isPositive($.trim(divided.priceStart))) {
		alert("请设置恰当的起始金额！");
		return false;
	}
	if(!isPositive($.trim(divided.priceEnd))) {
		alert("请设置恰当的结束金额！");
		return false;
	}
	if(parseFloat(divided.priceEnd) <= parseFloat(divided.priceStart)) {
		alert("结束金额不能小于开始金额！");
		return false;
	}
	if(!isPositive(divided.price) || divided.price < 0) {
		alert("请设置恰当的分成比列和额度！");
		return false;
	}
	return true;
};

/**  DividedDetail    **/
function _getDeletedDividedDetails() {
	var divided = {
			dividedDetailList : deletedDetails
	}
	return divided;
};
/**
 * 新增特殊类目
 */
function addSpecificDivided(e) {
    var prevSpecificDiv = $(e).parent().prev();
	specificTemplete.clone(true).show().attr('name', 'specific').insertAfter(prevSpecificDiv);
};

/**
 * <p>
 * 规则1:第一个梯度的起始值总是为0
 * 规则2:最后一个梯度的结束值总是为空（无穷大）
 * 规则3:	下一个梯度的起始值总是等于上一个梯度的结束值
 * @param e
 */
function addDividedDetail(e) {
	var tbody = $(e).parents('tbody');
	var lastTr = tbody.children('tr:last');
	var prevPriceEnd = lastTr.find('input[name=priceEnd]').val();
	if(!hasText(prevPriceEnd)) {
		alert('请设置金额梯度结束值！');
		return;
	}
	var prevPrice = lastTr.find('input[name=price]').val();
	if(!hasText(prevPrice)) {
		alert('请设置分成比例或者额度！');
		return;
	}
	//隐藏上一个梯度的删除操作
	lastTr.find('span:last').hide();
	var newLastTr = basicTemplete.clone(true).show();
	//下一个梯度的起始值总是等于上一个梯度的结束值
	newLastTr.find('input[name=priceStart]').val(prevPriceEnd);
	//总是添加到最后一行
	tbody.append(newLastTr);
};

/**
 * 删除该类目
 */
function delSpecificDivided(e) {
	var divided = $(e).parents('div[name=specific]');
    var dividedId = divided.attr('data-id');
    //如果是刚刚新增的，则可以直接删除
    if(!hasText(dividedId)) {
    	divided.remove();
        return;
    }
	if(window.confirm('确认删除设置吗?')){
		$.ajax({
	    	url     : "/mng/comm/rule/deldivided/" + dividedId,
		    success : function(data) {
		    	_successFun(data);
		    	if(data.code == 1) 
		    		divided.remove();
		    },
	        error   : _errorFun
	    })
	}else{
		return false;
	};
};

/**
 * 删除梯度
 */
function delDividedDetail(e){
    if($(e).parents('tbody').find('tr').size() == 1) {
        alert('该设置不能删除，至少得保存一个梯度设置！')
        return;
    }
    var currTr = $(e).parents('tr');
    var dividedDetailId = currTr.attr('data-id');
    //如果是新增的，可直接删除
    if(!hasText(dividedDetailId)) {
        currTr.prev().find('input[name=priceEnd]').val(null);
        currTr.prev().find('span').show();
        currTr.remove();
    	return;
    }
    if(window.confirm('请点击更新按钮进行删除保存操作!')){
    	currTr.prev().find('input[name=priceEnd]').val(null);
        currTr.prev().find('span').show();
        currTr.remove();
		var detail = {id : currTr.attr('data-id')}
		deletedDetails.push(detail);
	};
};

/**
 * 设置梯度改变菜单
 * @param e
 */
function cateChange(e) {
    var self = $(e);
    var nextCate = self.next();
    $.ajax({
	    url     : '/mng/comm/cate/findbyfid/' + self.val(),
	    success : function(data) {
	        var length = data.content.length;
	        var headOption = nextCate.find('option:first');
	        nextCate.empty();
	        nextCate.append($('<option>').val(-1).text("请选择三级分类"));
	        for(var i=0; i<length; i++) {
	            var option = $('<option>').val(data.content[i].id).text(data.content[i].name);
	            nextCate.append(option);
	        }
//	        nextCate.prepend(headOption);
	        nextCate.get(0).selectedIndex=0;
	    },
        error   : _errorFun
	})
}

