$(function() {
	$(".clear").bind("click",function () {
		$('#unionIdSelect').val("");
		$('#unionNameInput').val("");
		$('#directedIdSelect').val("");
	});
	$('#unionIdSelect').on("blur",function () {
		var unionIdSelect=$("#unionIdSelect").val();
		$('#unionInfo').empty();
		$.ajax({
			url : "/mng/comm/binding/searchUnionInfo",
			type : 'post',
			data : {
				'unionId' : unionIdSelect
			},
			dataType : 'json',
			cache: false,
			error : _errorFun,
			success : function(data) {
				if((data!=null)&&(data.users!=null)&&(data.users.pin!=null)){
						$('#unionNameInput').val(data.users.pin);
				}else{
					$('#unionNameInput').val("");
					$('#unionInfo').append("没有找到该站长。只有审核通过的站长才可以查到");
				}
			}
		});
	});
	$('#directedIdSelect').change(function() {
		var currOption = $(this).find(':selected');
		$('#directedStartTime').text(currOption.attr('data-starttime'));
		$('#directedEndTime').text(currOption.attr('data-endtime'));
	});

	$('#queryDirectedId').val($('#ruleId').val());
});

var formId = 'queryBindingForm';

function openSave() {
	if($('#directedIdSelect>option').length == 0) {
		alert("请先新建定向规则！");
		return;
	}
	$('#s1').show();
}

function save(){
	var channel=$("#channel").val();
	var options = {
			url : '/mng/comm/binding/save',
			success : function(data) {
				// 执行失败
				if (data.code == 0) {
					alert("执行失败，失败原因:" + data.msg);
				}
				// 执行成功
				else {
					alert("绑定规则成功");
					closeWindow();
					location.href = '/mng/comm/binding/'+channel;
				}
			}
	};
	$('#bindingForm').ajaxSubmit(options);
}

function closeWindow() {
	$('#s1').hide();
}

function del(e,unionId){
	if(confirm("确认删除该规则绑定吗？")) {
		$.ajax({
			url     : "/mng/comm/binding/del/" + $(e).parents('tr').attr('data-id') + "/" + unionId,
			success : function(data) {
				if(data.code == 1)
					$(e).parents('tr').remove();
			},
			error   : ""
		});
	}
}

function query(){

	$('#unionId').val($.trim($('#queryUnionId').val()));
	$('#unionName').val($.trim($('#queryUnionName').val()));
	$('#ruleId').val($.trim($('#queryDirectedId').val()));
	$('#startTime').val($.trim($('#queryStartTime').val()));
	$('#endTime').val($.trim($('#queryEndTime').val()));
	$('#queryBindingForm').submit();
}





