define([],function(){
    var _dom = {
        commissionSetting: $("#commissionSetting"),
        jtk: $("#jtk"),
        status: $("#status"),
        conte:$("#conte"),
        exportCommissionList: $("#exportCommissionList"),
        categoryCommissionForm: $("#categoryCommissionForm"),
        commissionHistoryWindow: $("#commissionHistoryWindow"),
        windowCancelBtn: $("#windowCancelBtn"),//历史弹窗的取消按钮
        windowSave: $("#windowSave"),
        windowCloseBtn: $("#commissionHistoryWindow").find(".close"),
        commissionTable: $("#commissionTable"),
        commissionHistoryTable: $("#commissionHistoryTable"),
        saveBtn: $("#saveBtn"),
        pageIndex: $("#pageIndex"),
        searchBtn: $("#searchBtn"),
        checkedNumber: $("#checkedNumber"),//checkNumber strong
        headCheckbox: $("#headCheckbox"),//thead checkbox
        showMulUpdateWindow: $("#showMulUpdateWindow"),//批量修改按钮
        mulUpdateSave: $("#mulUpdateSave"),//批量修改保存按钮
        mulUpdateCancel: $("#mulUpdateCancel"),//批量修改关闭按钮
        mulUpdateClose: $("#commissionMulUpdateWindow").find(".close"),//批量修改关闭按钮
        commissionMulUpdateWindow: $("#commissionMulUpdateWindow")//佣金比例批量修改页面
    };

    _dom.saveBtn.click(function() {
        var trData = getTrData(_dom.commissionTable.find(".mainTbody").children());
        var returnData = compareCommissionAndReturnData(trData.initCommissionArray, trData.lastCommissionArray);
        if(check(returnData)) {
            if(returnData.length <= 0) {
                alert("未修改任何值,不执行保存操作");
                return;
            }
            $.ajax({
                type:"POST",
                url:"/mng/category/commission/save",
                data:{commissionJson: JSON.stringify(returnData)},
                dataType:"json",
                success: function(data) {
                    if(data.code == 1) {
                        alert("佣金比例保存成功");
                        //location.href = "/mng/category/commission/list";
                        _dom.pageIndex.val(0);
                        _dom.categoryCommissionForm[0].submit();
                    } else {
                        alert("保存失败")
                    }
                },
                error: function(error) {

                }
            })
        }
    });

    _dom.headCheckbox.click(function(e) {
        var $children = _dom.commissionTable.find(".mainTbody").children();
        if($(this).prop("checked")) {
            $children.each(function() {
                $(this).find("input[name='chooseThirdId']").prop("checked", true);
            })
        } else {
            $children.each(function() {
                $(this).find("input[name='chooseThirdId']").prop("checked", false);
            })
        }
    });

    /**
     * 获得$trs的初始化佣金比例和当前佣金比例
     * @param $trs
     */
    function getTrData($trs) {
        var initCommissionArray = [];
        var lastCommissionArray = [];
        $trs.each(function(){
            var $tr = $(this);
            var initValue = $tr.find("input[name='initCommission']").val();
            var initCommission = {};
            var lastCommission = {};
            var initValues = initValue.split(",");
            var categoryLevel3Id = $tr.find("td").eq(3).attr("third-id");
            //装填初始化佣金比例
            initCommission["selfMobileComm"] = initValues[0];
            initCommission["selfPcComm"] = initValues[1];
            initCommission["popMobileComm"] = initValues[2];
            initCommission["popPcComm"] = initValues[3];
            initCommission["categoryLevel3Id"] = categoryLevel3Id;
            initCommissionArray.push(initCommission);
            //状态当前的佣金比例
            lastCommission["selfMobileComm"] = $tr.find("input[name='selfMobileComm']").val().trim();
            lastCommission["selfPcComm"] = $tr.find("input[name='selfPcComm']").val().trim();
            lastCommission["popMobileComm"] = $tr.find("input[name='popMobileComm']").val().trim();
            lastCommission["popPcComm"] = $tr.find("input[name='popPcComm']").val().trim();
            lastCommission["categoryLevel3Id"] = categoryLevel3Id;
            lastCommission["categoryLevel3Name"] = $tr.find("td").eq(3).text();
            lastCommissionArray.push(lastCommission);
        });

        return {
            initCommissionArray:initCommissionArray,
            lastCommissionArray:lastCommissionArray
        }
    }

    /**
     *
     * @param lastData 有变化的佣金比例值
     * @returns {boolean}
     */
    function check(lastData) {
        var flag = true;
        $.each(lastData, function(index, d) {
            var selfMobileComm_flag = true;
            var selfPcComm_flag = true;
            var popPcComm_flag = true;
            var popMobileComm_flag = true;
            if(d.selfMobileComm==""){
                selfMobileComm_flag = false;
            }
            if(d.selfPcComm==""){
                selfPcComm_flag = false;
            }
            if(d.popPcComm==""){
                popPcComm_flag = false;
            }
            if(d.popMobileComm==""){
                popMobileComm_flag = false;
            }
            if(!(selfMobileComm_flag && selfPcComm_flag && popPcComm_flag && popMobileComm_flag)){
                alert(d["categoryLevel3Name"]+"的佣金比例不允许某一项为空");
                flag = false;
                return false;
            }
            if(isNaN(d.selfMobileComm) || isNaN(d.selfPcComm) || isNaN(d.popPcComm) || isNaN(d.popMobileComm)) {
                alert(d["categoryLevel3Name"]+"的佣金比例不为数字");
                flag = false;
                return false;
            }
            var selfmobileCommArray = d.selfMobileComm.split(".");
            var selfPcCommArray = d.selfPcComm.split(".");
            var popPcCommArray = d.popPcComm.split(".");
            var popMobileCommArray = d.popMobileComm.split(".");
            if(selfmobileCommArray.length == 2 && selfmobileCommArray[1].length != 1) {
                alert("自营无线佣金比例必须为一位小数");
                flag = false;
                return false;
            }
            if(selfPcCommArray.length == 2 && selfPcCommArray[1].length != 1) {
                alert("自营PC佣金比例必须为一位小数");
                flag = false;
                return false;
            }
            if(popPcCommArray.length == 2 && popPcCommArray[1].length != 1) {
                alert("POP PC佣金比例必须为一位小数");
                flag = false;
                return false;
            }
            if(popMobileCommArray.length == 2 && popMobileCommArray[1].length != 1) {
                alert("POP无线佣金比例必须为一位小数");
                flag = false;
                return false;
            }
            var selfMobileCommInteger = parseFloat(d.selfMobileComm, 10);
            var selfPcCommInteger = parseFloat(d.selfPcComm, 10);
            var popPcCommInteger = parseFloat(d.popPcComm, 10);
            var popMobileCommInteger = parseFloat(d.popMobileComm, 10);
            if(selfMobileCommInteger > 80 || selfPcCommInteger > 80 || popPcCommInteger > 80 || popMobileCommInteger > 80) {
                alert(d["categoryLevel3Name"]+"的佣金比例不能大于80");
                flag = false;
                return false;
            }
            if(selfMobileCommInteger < 0 || selfPcCommInteger < 0 || popPcCommInteger < 0 || popMobileCommInteger < 0) {
                alert(d["categoryLevel3Name"]+"的佣金比例不能小于0");
                flag = false;
                return false;
            }
        });

        return flag;
    }

    //查询按钮事件
    _dom.searchBtn.click(function() {
        _dom.pageIndex.val(0);
        _dom.categoryCommissionForm[0].submit();
    });

    function compareCommissionAndReturnData(initCommissionArray, lastCommissionArray) {
        var returnData = [];
        $.each(initCommissionArray, function(index, data) {
            var lastData = lastCommissionArray[index];
            if(data.selfMobileComm == lastData.selfMobileComm
                && data.selfPcComm == lastData.selfPcComm
                && data.popMobileComm == lastData.popMobileComm
                && data.popPcComm == lastData.popPcComm
                && data.categoryLevel3Id == lastData.categoryLevel3Id) {

            } else {
                returnData.push(lastData)
            }
        });

        return returnData;
    }

    var commissionSettingValue = _dom.commissionSetting.attr("value");
    _dom.commissionSetting.children().each(function(index) {
        if($(this).val() == commissionSettingValue) {
            $(this).attr("selected", true);
            return false;
        }
    });

    var statusValue = _dom.status.attr("value");
    _dom.status.children().each(function(index) {
        if($(this).val() == statusValue) {
            $(this).attr("selected", true);
            return false;
        }
    });
    var conteValue = _dom.conte.attr("value");
    _dom.conte.children().each(function(index) {
        if($(this).val() == conteValue) {
            $(this).attr("selected", true);
            return false;
        }
    });
    //导出按钮的点击事件
    _dom.exportCommissionList.click(function(e) {
        exp();
    });

    //导出文件
    function exp() {
        var formData = _dom.categoryCommissionForm.serializeArray();
        var str = "?";
        for(var i = 0, length = formData.length; i < length; i++) {
            str += formData[i].name + "=" + formData[i].value + "&";
        }
        str = str.substring(0, str.length - 1);
        //console.log(str);
        location.href = "/mng/category/commission/export"+str;
    }

    _dom.commissionTable.click(function(e) {
        var target = e.target;
        //响应查看事件
        if(target.className == 'showCommissionHistory') {
            var thirdId = $(target).attr("third-id");
            drawHistoryWindow(thirdId);
        }
    });

    _dom.windowCancelBtn.click(function() {
        _dom.commissionHistoryWindow.hide();
    });

    _dom.windowSave.click(function() {
        _dom.commissionHistoryWindow.hide();
    });

    _dom.windowCloseBtn.click(function() {
        _dom.commissionHistoryWindow.hide();
    });

    function drawHistoryWindow(thirdId) {
        _dom.commissionHistoryWindow.show();
        $.ajax({
            type:"GET",
            url:"/mng/category/commission/history/"+thirdId,
            data:{},
            dataType:"json",
            success: function(data) {
                var $tbody = _dom.commissionHistoryTable.find("tbody");
                $tbody.empty();
                $.each(data, function(index, d) {
                    var $tr = $("<tr></tr>");
                    $tr.append(
                        "<td>"+ d.operationPerson+"</td>"+
                        "<td>"+ d.updateTime+"</td>"+
                        "<td>"+ d.selfMobileComm+"</td>"+
                        "<td>"+ d.selfPcComm+"</td>"+
                        "<td>"+ d.popMobileComm+"</td>"+
                        "<td>"+ d.popPcComm+"</td>"+
                        "<td>"+ d.beginDate+"-"+ d.endDate+"</td>"
                    );
                    $tr.appendTo($tbody);
                });
            },
            error: function(error) {

            }
        })
    }

    function getCheckedTr() {
        var checkTrs = [];
        _dom.commissionTable.find(".mainTbody").children().each(function() {
            var $this = $(this);
            if($this.find("td").eq(0).find("input").prop("checked") == true) {
                checkTrs.push($this);
            }
        });

        return checkTrs;
    }

    _dom.showMulUpdateWindow.click(function() {
        var length = getCheckedTr().length;
        _dom.checkedNumber.html(length)
        if(length > 0) {
            _dom.commissionMulUpdateWindow.show();
        } else {
            alert("请先选择要修改的三级类目");
        }
    });
    _dom.mulUpdateSave.click(function() {
        var trs = getCheckedTr();
        if(trs.length == 0) {
            alert("请选择要修改的三级类目");
            return false;
        }
        var returnData = [];
        $.each(trs, function(index, $tr) {
            var categoryLevel3Id = $tr.find("td").eq(3).attr("third-id");
            var commission = {};
            commission["selfMobileComm"] = _dom.commissionMulUpdateWindow.find("input[name='selfMobileComm']").val().trim();
            commission["selfPcComm"] = _dom.commissionMulUpdateWindow.find("input[name='selfPcComm']").val().trim();
            commission["popMobileComm"] = _dom.commissionMulUpdateWindow.find("input[name='popMobileComm']").val().trim();
            commission["popPcComm"] = _dom.commissionMulUpdateWindow.find("input[name='popPcComm']").val().trim();
            commission["categoryLevel3Id"] = categoryLevel3Id;
            commission["categoryLevel3Name"] = $tr.find("td").eq(3).text();
            returnData.push(commission);
        });

        if(check(returnData)) {
            if(returnData.length <= 0) {
                alert("未修改任何值,不执行保存操作");
                return;
            }
            $.ajax({
                type:"POST",
                url:"/mng/category/commission/save",
                data:{commissionJson: JSON.stringify(returnData)},
                dataType:"json",
                success: function(data) {
                    if(data.code == 1) {
                        alert("佣金比例保存成功");
                        //location.href = "/mng/category/commission/list";
                        _dom.pageIndex.val(0);
                        _dom.categoryCommissionForm[0].submit();
                    } else {
                        alert("保存失败")
                    }
                },
                error: function(error) {

                }
            })
        }
    });
    _dom.mulUpdateClose.click(function() {
        _dom.commissionMulUpdateWindow.hide();
    });
    _dom.mulUpdateCancel.click(function() {
        _dom.commissionMulUpdateWindow.hide();
    });
});

String.prototype.endWith=function(s){
    if(s==null||s==""||this.length==0||s.length>this.length)
        return false;
    if(this.substring(this.length-s.length)==s)
        return true;
    else
        return false;
    return true;
};
String.prototype.startWith=function(s){
    if(s==null||s==""||this.length==0||s.length>this.length)
        return false;
    if(this.substr(0,s.length)==s)
        return true;
    else
        return false;
    return true;
};