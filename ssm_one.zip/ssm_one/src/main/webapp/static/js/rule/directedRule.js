define([],function(){

    //佣金比例初始化时间
    $(function() {
        setDefaultRuleDate();
    });
    function setDefaultRuleDate() {
        var next = nextDay().format("yyyy-MM-dd");
        $('#startTime').val(next);
    }

	/**
	 * 查看
	 */
	$(".showRuleDirected").bind("click",function(){
		var ruleId = $(this).data("ruleid");
		var name = $(this).data("name");
		var channel = $('#source').val();
		window.location.href='/mng/comm/rule/view/directed/'+ruleId+'/'+encodeURIComponent(encodeURIComponent(name))+'/'+channel;
	});
	
	/**
	 * 修改
	 */
	$(".updRuleDirected").bind("click",function(){
		var ruleId = $(this).data("upruleid");
		var name = $(this).data("upname");
		var channel = $('#source').val();
		window.location.href='/mng/comm/rule/toupd/directed/'+ruleId+'/'+encodeURIComponent(encodeURIComponent(name))+'/'+channel;
	});
	
	/**
	 * 删除
	 */
	$(".del").bind("click",function(){
		var e = $(this);
		var delUrl = '/mng/comm/rule/del/usual/';
		if(window.confirm('确认删除设置吗?')){
			$.ajax({
		    	url : delUrl + $(e).parents('tr').attr("data-id"),
			    success : function(data) {
			    	_successFun(data);
			    	if(data.code == 1) 
			    	    $(e).parents('tr').remove();
			    },
		        error   : _errorFun
		    })
		}else{
			return false;
		};

	});
	
	/**
	 * 修改比例
	 */
	$(".update").bind("click",function(){
		var type = $(this).data("type");
		var url = $(this).data("url")+"?date"+new Date();
		$.ajax({
			url : url,
			cache: false,
			error : function() {
				alert("代码出错，请稍后再试！");
			},
			success : function(data) {
				$('#ruleId').val(data.content.id);
				$('#cusRatio').val(data.content.customRatio);
				$('#lblDate').html(data.content.startTime + " 至 " + data.content.endTime);
				if(type == 2)
					$('#lblName').html(data.content.name);
			}
		});
	});
	
	/**
	 * 新建规则
	 */
	$("#save").bind("click",function(){
		if(validateRule()) {
			$('#ruleForm').submit();
		}
	});
	
	/**
	 * 新建规则-验证规则
	 */
	function validateRule() {
		if($('#name').size() > 0 && !hasText($('#name').val())) {
			alert("请填写规则名称!");
			return;
		}
		var customRatio = $('#customRatio').val();
		if($('#customRatio').size() > 0 && !hasText(customRatio)) {
			alert("请填写佣金比例!");
			return;
		}else{
			if(checkInput(customRatio)==false || IsInt(customRatio)==false ||
					customRatio < 0 || customRatio > 100){
				alert('请正确输入佣金比例范围');
				return false;
			}
		}
		var startTime = $('#startTime').val();
		var endTime = $('#endTime').val();
		return dateCompare(startTime, endTime);
	};
	
	/**
	 * 修改佣金比例
	 */
	$("#updateRatio").bind("click",function(){
		var type = $(this).data("newtype");
		var channel = $('#source').val();
		var customRatio = $('#cusRatio').val();
		if($('#cusRatio').size() > 0 && !hasText(customRatio)) {
			alert("请填写佣金比例!");
			return;
		}else{
			if(checkInput(customRatio)==false || IsInt(customRatio)==false ||
					customRatio < 0 || customRatio > 100){
				alert('请正确输入佣金比例范围');
				return false;
			}
		}
		var ruleId = $('#ruleId').val();
		$.ajax({
			url : "/mng/comm/rule/update/usual",
			type : 'post',
			cache: false,
			data : {
				'ruleId' : ruleId,
				'cusRatio' : customRatio
			},
			dataType : 'json',
			error : function() {
				alert("代码出错，请稍后再试！");
			},
			success : function(data) {
				_successFun(data);
				if(type == 1)
					window.location.href = "/mng/comm/rule/usual/" + channel;
				if(type == 2)
					window.location.href = "/mng/comm/rule/directed/" + channel;
				if(type == 3)
					window.location.href = "/mng/comm/rule/bonus/" + channel;
			}
		});
	});
	
	//新建复制规则
	$(".copyNew").bind("click",function(){
		var ruleId = $(this).data("ruleid");
		var customRatio = $(this).data("rto");
		var name = $(this).data("name");
		var endTime = $(this).data("et");
		$('#sTime').val(nextDay(endTime).format("yyyy-MM-dd"));
        $('#cRatio').val(parseInt(customRatio));
        $('#rId').val(ruleId);
        $('#rName').val("复制" + name);
        $("#copyNewRule").click();
	});
	var checkSubmitFlg = false; 
	//新建复制规则保存
	$("#saveCopy").unbind("click").bind("click",function(){
		if(validateCopyRule()) {
			if (!checkSubmitFlg) {          
				checkSubmitFlg = true;              
				$('#copyUsualForm').submit();
			}else{          
				alert("不能重复提交");          
				return false;         
			} 
		}
	});
	function validateCopyRule() {
		if($('#rName').size() > 0 && !hasText($('#rName').val())) {
			alert("请填写规则名称!");
			return false;
		}
		var customRatio = $('#cRatio').val();
		if($('#cRatio').size() > 0 && !hasText(customRatio)) {
			alert("请填写佣金比例!");
			return false;
		}else{
			if(checkInput(customRatio)==false || IsInt(customRatio)==false ||
					customRatio < 0 || customRatio > 100){
				alert('请正确输入佣金比例范围');
				return false;
			}
		}
		var startTime = $('#sTime').val();
		var endTime = $('#eTime').val();
		return dateCompare(startTime, endTime);
	};
});