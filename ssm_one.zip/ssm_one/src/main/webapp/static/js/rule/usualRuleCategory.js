define([],function(){
	
	/**
	 * 通用规则页面查看
	 */
	$(".viewDivided").bind("click",function(){
		var viewUrl = $(this).data("viewurl");
		var tr = $(this).parents('tr');
		$('#cateId').val(tr.children(':eq(0)').text());
		$('#cateName').val(tr.children(':eq(1)').text());
		$('#dividedForm').attr('action', viewUrl);
		$('#dividedForm').submit();
		
	});
	
	/**
	 * 通用规则页面设置
	 */
	$(".setDivided").bind("click",function(){
		var setUrl = $(this).data("seturl");
		var tr = $(this).parents('tr');
		$('#cateId').val(tr.children(':eq(0)').text());
		$('#cateName').val(tr.children(':eq(1)').text());
		$('#dividedForm').attr('action', setUrl);
		$('#dividedForm').submit();
	});
	
	
	/**
	 * 查看页面滑过效果
	 */
	jQuery(document).ready(function(){
		//
		$('[data-toggle="rulelist"]').popover({
			trigger: 'hover',
			html: true,
			placement: 'auto',
			content: function() {
				var hoverPage =  $(this).data("content");
				
				return hoverPage;
			}
		});
		$('[data-toggle="rulelistt"]').popover({
			trigger: 'hover',
			html: true,
			placement: 'auto',
			content: function() {


				var hoverPage = $(this).data("content");

				return hoverPage;
			}
		});
	});
})
