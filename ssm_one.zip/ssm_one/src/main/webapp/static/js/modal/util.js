/**
* json对象向String转化
* author 黎巍
*/
function jsonToString (obj){   
 var THIS = this;    
 switch(typeof(obj)){   
     case 'string':   
         return '"' + obj.replace(/(["\\])/g, '\\$1') + '"';   
     case 'array':   
         return '[' + obj.map(THIS.jsonToString).join(',') + ']';   
     case 'object':   
          if(obj instanceof Array){   
             var strArr = [];   
             var len = obj.length;   
             for(var i=0; i<len; i++){   
                 strArr.push(THIS.jsonToString(obj[i]));   
             }   
             return '[' + strArr.join(',') + ']';   
         }else if(obj==null){   
             return 'null';   

             }else{   
                 var string = [];   
                 for (var property in obj) string.push(THIS.jsonToString(property) + ':' + THIS.jsonToString(obj[property]));   
             return '{' + string.join(',') + '}';   
         }   
     case 'number':   
         return obj;   
     case 'false':   
         return obj;   
 }   
}

/**
* String向json对象转化
* author 黎巍
*/
function stringToJSON(obj){   
	return eval('(' + obj + ')');   
}

//将整数日期1355131810000格式化为2012-01-01格式
function formateIntDateToString(intDate){
	var d=new Date(intDate);
	var year=d.getFullYear();
	var month=d.getMonth()+1;
	if(month>=10){
		month = month + "";
	}else{
		month = "0"+month;
	}
	var date=d.getDate();
	if(date<10){
		date = "0" + date;
	}
	return year+"-"+month+"-"+date;
}
//将日期对象格式化为"20120101"
function formateDateObjToString(dateObj,split){
	var month = dateObj.getMonth()+1;
	if(month<10){
		month = "0"+month;
	}
	var day = dateObj.getDate();
	if(day<10){
		day = "0" + day;
	}
	if(!split){
		split = "";
	}
	return dateObj.getFullYear() + split + month + split + day;
}
/**
* 校验url合法
* @param str_url
* @returns {Boolean}
*/
function IsURL(str_url){
	
	var urlreg=/^((https|http|ftp|rtsp|mms)?:\/\/)+[A-Za-z0-9]+\.[A-Za-z0-9]+[\/=\?%\-&_~`@[\]\':+!]*([^<>\"\"])*$/  ;
	var re=new RegExp(urlreg);
	//re.test()
	if (re.test(str_url)){
		return true;
	}else{
		return false;
	}
}
/**
* 校验url是否为京东主站
* @param str_url
* @returns {Boolean}
*/
function IsJdURL(str_url){
	
	var urlreg=/\.jd\.com\//;
	var re=new RegExp(urlreg);
	if (re.test(str_url)){
		return true;
	}else{
		return false;
	}
}