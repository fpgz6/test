function add_A_test(href,title){
    require(['testModel'], function (testModel) {
        testModel.add_A(href,title);
    });
}