define(['jquery'], function ($, _) {

    return {
        add_A: function (hre, title) {
            var a = "<a href='"+hre+"'>"+title+"</a>"
            $(document.body).append(a);
        }

    }
});