var url = "/college/modify";
$(document).ready(function() {
	$("#newUser").bind("click", function() {
		showNewUser();
		url = "/college/create";
	});
	$("#saveUser").bind("click", function() {
		save();
	});
	$("#delUserOp").bind("click", function() {
		var id = $(this).data("id");
		$('#rId').val(id);
	});
	$("#modUserOp").bind("click", function() {
//		var row = $(this).data("row");
//		alert(row);
//		alert(eval(row));
		$('#id').val($(this).data("id"));
		$('#school').val($(this).data("school"));
		$('#grade').val($(this).data("grade"));
		$('#province').val($(this).data("province"));
		$('#city').val($(this).data("city"));
		$('#area').val($(this).data("area"));
		$('#middleSchool').val($(this).data("middleSchool"));
		$('#sex').val($(this).data("sex"));
		$('#age').val($(this).data("age"));
		$('#major').val($(this).data("major"));
		$('#selfIntroduce').val($(this).data("selfIntroduce"));
	});
	$("#delUser").bind("click", function() {
		var id = $('#rId').val();
		delUser(id);
	});
});

function showNewUser(){
	$('#id').val("");
	$('#school').val("");
	$('#grade').val("");
	$('#province').val("");
	$('#city').val("");
	$('#area').val("");
	$('#middleSchool').val("");
	$('#sex').val("");
	$('#age').val("");
	$('#major').val("");
	$('#selfIntroduce').val("");
}
	


function save() {
	var reqData = {};
	var formArray = $('#updateForm').serializeArray();
	$.each(formArray, function(idx, item) {
		reqData[item.name] = item.value;
	});
	// var data = {
	// roleId : $('#roleId').val(),
	// ids : $('#ids').val(),
	// name : newName
	// };
	$.ajax({
		async : false,
		type : "post",
		data : reqData,
		url : url,
		success : function(data) {
			if (data == "true") {
				alert('操作成功!');
				window.location.href = '/college/index';
			} else {
				alert('亲，操作失败，请稍后再试！');
			}
		},
		error : function() {
			alert("代码出错，请稍后再试！");
		}
	});
}



function delUser(id) {
	$.ajax({
		url : "/college/del",
		type : 'post',
		cache : false,
		data : {
			'id' : id
		},
		dataType : 'json',
		error : function() {
			alert("代码出错，请稍后再试！");
		},
		success : function(data) {
			if (data == true) {
				alert('操作成功!');
				window.location.href = '/college/index';
			} else {
				alert('亲，操作失败，请稍后再试！');
			}
		}
	});
}