var url = "/student/modify";
$(document).ready(function() {
	$("#newRecord").bind("click", function() {
		showNewRecord();
		url = "/student/create";
	});
	$("#saveRecord").bind("click", function() {
		save();
	});
	$("#delRecordOp").bind("click", function() {
		var id = $(this).data("id");
		$('#rId').val(id);
	});
	$("#modRecordOp").bind("click", function() {
//		var row = $(this).data("row");
//		alert(row);
//		alert(eval(row));
		$('#studentId').val($(this).data("studentId"));
		$('#name').val($(this).data("name"));
		$('#phoneNumber').val($(this).data("phoneNumber"));
		$('#registerTime').val($(this).data("registerTime"));
		$('#money').val($(this).data("money"));
		$('#state').val($(this).data("state"));
	});
	$("#delRecord").bind("click", function() {
		var id = $('#rId').val();
		delRecord(id);
	});
});
function showNewRecord(){
	$('#studentId').val("");
	$('#name').val("");
	$('#phoneNumber').val("");
	$('#registerTime').val("");
	$('#money').val("");
	$('#state').val("");
}
	


function save() {
	var reqData = {};
	var formArray = $('#updateForm').serializeArray();
	$.each(formArray, function(idx, item) {
		reqData[item.name] = item.value;
	});
	// var data = {
	// roleId : $('#roleId').val(),
	// ids : $('#ids').val(),
	// name : newName
	// };
	$.ajax({
		async : false,
		type : "post",
		data : reqData,
		url : url,
		success : function(data) {
			if (data == "true") {
				alert('操作成功!');
				window.location.href = '/student/index';
			} else {
				alert('亲，操作失败，请稍后再试！');
			}
		},
		error : function() {
			alert("代码出错，请稍后再试！");
		}
	});
}



function delRecord(id) {
	$.ajax({
		url : "/student/del",
		type : 'post',
		cache : false,
		data : {
			'id' : id
		},
		dataType : 'json',
		error : function() {
			alert("代码出错，请稍后再试！");
		},
		success : function(data) {
			if (data == true) {
				alert('操作成功!');
				window.location.href = '/student/index';
			} else {
				alert('亲，操作失败，请稍后再试！');
			}
		}
	});
}