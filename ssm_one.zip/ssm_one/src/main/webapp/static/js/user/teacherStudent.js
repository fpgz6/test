var url = "/teacherStudent/modify";
$(document).ready(function() {
	$("#newRecord").bind("click", function() {
		showNewRecord();
		url = "/teacherStudent/create";
	});
	$("#saveRecord").bind("click", function() {
		save();
	});
	$("#delRecordOp").bind("click", function() {
		var id = $(this).data("id");
		$('#rId').val(id);
	});
	$("#modRecordOp").bind("click", function() {
//		var row = $(this).data("row");
//		alert(row);
//		alert(eval(row));
		$('#teacherId').val($(this).data("teacherId"));
		$('#studentId').val($(this).data("studentId"));
		$('#buildTime').val($(this).data("buildTime"));
		$('#teacherNickname').val($(this).data("teacherNickname"));
		$('#studentNickname').val($(this).data("studentNickname"));
	});
	$("#delRecord").bind("click", function() {
		var id = $('#rId').val();
		delRecord(id);
	});
});

function showNewRecord(){
	$('#teacherId').val("");
	$('#studentId').val("");
	$('#buildTime').val("");
	$('#teacherNickname').val("");
	$('#studentNickname').val("");
}
	


function save() {
	var reqData = {};
	var formArray = $('#updateForm').serializeArray();
	$.each(formArray, function(idx, item) {
		reqData[item.name] = item.value;
	});
	// var data = {
	// roleId : $('#roleId').val(),
	// ids : $('#ids').val(),
	// name : newName
	// };
	$.ajax({
		async : false,
		type : "post",
		data : reqData,
		url : url,
		success : function(data) {
			if (data == "true") {
				alert('操作成功!');
				window.location.href = '/teacherStudent/index';
			} else {
				alert('亲，操作失败，请稍后再试！');
			}
		},
		error : function() {
			alert("代码出错，请稍后再试！");
		}
	});
}



function delRecord(id) {
	$.ajax({
		url : "/teacherStudent/del",
		type : 'post',
		cache : false,
		data : {
			'id' : id
		},
		dataType : 'json',
		error : function() {
			alert("代码出错，请稍后再试！");
		},
		success : function(data) {
			if (data == true) {
				alert('操作成功!');
				window.location.href = '/teacherStudent/index';
			} else {
				alert('亲，操作失败，请稍后再试！');
			}
		}
	});
}