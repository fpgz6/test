$(document).ready(function() {
	$("#submitLogin").bind("click", function() {
		submitLogin();
	});
});

function submitLogin() {
	var reqData = {};
	var formArray = $('#submitForm').serializeArray();
	$.each(formArray, function(idx, item) {
		reqData[item.name] = item.value;
	});
	// var data = {
	// roleId : $('#roleId').val(),
	// ids : $('#ids').val(),
	// name : newName
	// };
	$.ajax({
		async : false,
		type : "post",
		data : reqData,
		url : "/submitLogin",
		success : function(data) {
			if (data == "true") {
				window.location.href = '/online/index';
			} else {
				alert('亲，登录失败，请稍后再试！');
			}
		},
		error : function() {
			alert("代码出错，请稍后再试！");
		}
	});
}



function delRecord(id) {
	$.ajax({
		url : "/student/del",
		type : 'post',
		cache : false,
		data : {
			'id' : id
		},
		dataType : 'json',
		error : function() {
			alert("代码出错，请稍后再试！");
		},
		success : function(data) {
			if (data == true) {
				alert('操作成功!');
				window.location.href = '/student/index';
			} else {
				alert('亲，操作失败，请稍后再试！');
			}
		}
	});
}