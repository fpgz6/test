$(document).ready(function() {
	$("#newRecord").bind("click", function() {
		showNewRecord();
	});
	$("#saveRecord").bind("click", function() {
		save();
	});
	$("#delRecordOp").bind("click", function() {
		var id = $(this).data("id");
		$('#rId').val(id);
	});
	$("#modRecordOp").bind("click", function() {
//		var row = $(this).data("row");
//		alert(row);
//		alert(eval(row));
		$('#resourceId').val($(this).data("resourceId"));
		$('#teacherId').val($(this).data("teacherId"));
		$('#studentId').val($(this).data("studentId"));
		$('#uploadTime').val($(this).data("uploadTime"));
		$('#topic').val($(this).data("topic"));
		$('#url').val($(this).data("url"));
	});
	$("#delRecord").bind("click", function() {
		var id = $('#rId').val();
		delRecord(id);
	});
});

function showNewRecord(){
	$('#resourceId').val("");
	$('#teacherId').val("");
	$('#studentId').val("");
	$('#uploadTime').val("");
	$('#topic').val("");
	$('#url').val("");
}
	


function save() {
	var reqData = {};
	var formArray = $('#updateForm').serializeArray();
	$.each(formArray, function(idx, item) {
		reqData[item.name] = item.value;
	});
	// var data = {
	// roleId : $('#roleId').val(),
	// ids : $('#ids').val(),
	// name : newName
	// };
	$.ajax({
		async : false,
		type : "post",
		data : reqData,
		url : "/homework/modify",
		success : function(data) {
			if (data == "true") {
				alert('操作成功!');
				window.location.href = '/homework/index';
			} else {
				alert('亲，操作失败，请稍后再试！');
			}
		},
		error : function() {
			alert("代码出错，请稍后再试！");
		}
	});
}



function delRecord(id) {
	$.ajax({
		url : "/homework/del",
		type : 'post',
		cache : false,
		data : {
			'id' : id
		},
		dataType : 'json',
		error : function() {
			alert("代码出错，请稍后再试！");
		},
		success : function(data) {
			if (data == true) {
				alert('操作成功!');
				window.location.href = '/homework/index';
			} else {
				alert('亲，操作失败，请稍后再试！');
			}
		}
	});
}